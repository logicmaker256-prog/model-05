// ============================================================
// プリセット＝スロット管理（11スロット、編集可能）
// ============================================================
const SLOT_COUNT = POSES.length; // POSES件数に自動追従（ドラゴンバスター勇者用13ポーズ）
const LS_KEY     = '3dmaker_myslots_v3'; // ポーズ内容を刷新したのでバージョンを上げてリセット

// POSESをスナップショット形式に変換するヘルパー
function poseDefToSnapshot(pose) {
    if (!pose) return null;
    return {
        head: { rx: pose.head?.rx ?? 0, ry: pose.head?.ry ?? 0, rz: pose.head?.rz ?? 0 },
        arms: (pose.arms || []).map(a => ({
            root:  { rx: a.root?.rx ?? 0, ry: a.root?.ry ?? 0, rz: a.root?.rz ?? 0 },
            joint: { rx: a.joint?.rx ?? 0, rz: a.joint?.rz ?? 0 },
            wrist: { rx: a.wrist?.rx ?? 0, ry: a.wrist?.ry ?? 0, rz: a.wrist?.rz ?? 0 },
        })),
        legs: (pose.legs || []).map(l => ({
            root:  { rx: l.root?.rx ?? 0, rz: l.root?.rz ?? 0 },
            joint: { rx: l.joint?.rx ?? 0 },
        })),
        swordTiltX: pose.swordTiltX ?? 0,
    };
}
window.poseDefToSnapshot = poseDefToSnapshot;

// 初期スロットに、ポーズの用途に合った表情プリセットを最初から割り当てておく
// （表情プリセット表の「用途」列と完全一致するものだけ選定。曖昧なものは
//   OFF＝デフォルト表情のままにしておく）
const DEFAULT_SLOT_EXPRESSIONS = {
    '😊 待機':                     'normal',     // 待機・歩き
    '⚔️ 大剣構え':                 'serious',    // ボス戦・構え
    '⚔️ 大剣攻撃・振りかぶり':     'angry',      // 攻撃・必殺技
    '⚔️ 大剣攻撃・斬り下ろし':     'angry',      // 攻撃・必殺技
    '😵 ダメージ':                  'surprised',  // ダメージ・イベント
    '🏆 勝利':                      'smile',      // 会話・勝利
};

// デフォルトスロット（プリセット7種の初期値）
function defaultSlots() {
    return POSES.slice(0, SLOT_COUNT).map((pose, i) => {
        const exprKey = DEFAULT_SLOT_EXPRESSIONS[pose.label] || null;
        const preset  = exprKey ? EXPRESSION_PRESETS.find(p => p.key === exprKey) : null;
        return {
            name:          pose.label,          // 絵文字込みの元のラベル
            poseSnapshot:  poseDefToSnapshot(pose),
            isDefault:     true,                // リセット用フラグ
            defaultIndex:  i,                   // POSES[i]のindex
            // ★表情システム：スロットごとに完全に独立したオブジェクトを持たせる
            //   （cloneExpressionで必ずディープコピーし、同じ参照を共有しない）
            expressionEnabled: !!preset,
            expressionKey:     exprKey || 'normal',
            expression:        cloneExpression(preset || DEFAULT_EXPRESSION),
        };
    });
}

// 保存データにexpression関連フィールドが無い（旧形式）場合に安全な初期値を補い、
// 併せてexpressionを必ずディープコピーして独立させる。
function normalizeSlotExpression(slot) {
    if (!slot) return slot;
    if (typeof slot.expressionEnabled !== 'boolean') slot.expressionEnabled = false;
    if (!slot.expressionKey) slot.expressionKey = 'normal';
    slot.expression = cloneExpression(slot.expression || DEFAULT_EXPRESSION);
    return slot;
}

// 保存済みスロット配列を、現在のPOSES構成に合わせて復元する。
// 「名前」で対応づけるので、新しいポーズが途中に追加されて番号がズレても、
// 既存の（編集済みの）ポーズが別のポーズの位置にずれ込んで壊れることがない。
// 名前が一致しないもの（新規追加されたポーズ等）はそのスロットの初期値になる。
function reconcileSlots(savedArr) {
    const defaults = defaultSlots();
    if (!Array.isArray(savedArr) || savedArr.length === 0) return defaults;

    const byName = {};
    savedArr.forEach(s => { if (s && s.name) byName[s.name] = s; });

    return defaults.map(def => byName[def.name] || def);
}

function loadSlots() {
    try {
        const raw = localStorage.getItem(LS_KEY);
        if (raw) {
            const arr = JSON.parse(raw);
            if (Array.isArray(arr) && arr.length === SLOT_COUNT) return arr.map(normalizeSlotExpression);
            if (Array.isArray(arr) && arr.length > 0) return reconcileSlots(arr).map(normalizeSlotExpression);
        }
    } catch(e) {}
    return defaultSlots();
}

function saveSlots(slots) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(slots)); } catch(e) {}
}

let mySlots = loadSlots();

// 現在「選択中」のプリセット番号（-1 = どのプリセットにも紐付かない状態＝アイドル/コマンド再生中など）
// このスロットに対してポーズを編集すると自動的に上書き保存される
let activeSlotIndex = 0;

let _autoSaveTimer = null;
function autoSaveActiveSlot() {
    clearTimeout(_autoSaveTimer);
    _autoSaveTimer = setTimeout(() => {
        if (activeSlotIndex < 0 || !mySlots[activeSlotIndex]) return;
        const snap = captureFullPoseSnapshot();
        if (!snap) return;
        mySlots[activeSlotIndex].poseSnapshot = snap;
        mySlots[activeSlotIndex].isDefault    = false;
        saveSlots(mySlots);
        showSlotStatus(`✅ プリセット${activeSlotIndex + 1}「${mySlots[activeSlotIndex].name}」に自動保存しました`);
    }, 400);
}

// 現在の3Dポーズ状態をスナップショット
function captureFullPoseSnapshot() {
    return snapshotCurrentRotations();
}

// スナップショットをシーン上の骨格に適用
function applyPoseSnapshot(snapshot) {
    if (!snapshot) return;
    const p = animatedParts;
    if (!p.arms || !p.arms.length) return;

    // Quaternionを用いてボーンへ回転を適用する（Euler角の個別代入はしない）
    function setR(obj, rx=0, ry=0, rz=0) {
        setBoneAnglesAsQuaternion(obj, rx, ry, rz);
    }

    if (p.head) setR(p.head, snapshot.head.rx, snapshot.head.ry, snapshot.head.rz);

    p.arms.forEach((arm, i) => {
        const a = snapshot.arms[i];
        if (!a) return;
        setR(arm.root,  a.root.rx,  a.root.ry,  a.root.rz);
        setR(arm.joint, a.joint.rx, 0,           a.joint.rz);
        setR(arm.wrist, a.wrist?.rx ?? 0, a.wrist?.ry ?? 0, a.wrist?.rz ?? 0);
    });
    p.legs.forEach((leg, i) => {
        const l = snapshot.legs[i];
        if (!l) return;
        setR(leg.root,  l.root.rx, 0, l.root.rz);
        setR(leg.joint, l.joint.rx, 0, 0);
    });
    if (p.sword && snapshot.swordTiltX !== undefined) {
        p.sword.rotation.x = SWORD_BASE_ROTATION.x + snapshot.swordTiltX;
    }

    // ポーズ補間を完了済みに（_poseEditApplyAfterPoseが余計に呼ばれないよう先にnullにする）
    poseTarget = null; poseFrom = null; poseT = 1.0;
    idleEnabled = false;
    syncIdleSelect(false);

    // ポーズ編集パネルのdegテーブルをスナップショット値に同期
    // （同期しないと_poseEditApplyAfterPoseが全0で上書きしてしまう）
    if (window._poseEditSyncDeg) window._poseEditSyncDeg(snapshot);
}

// ── スロットUI構築 ──────────────────────────────────────────
let slotEditTarget = -1;

function buildSlotButtons() {
    const container = document.getElementById('pose-slot-buttons');
    if (!container) return;
    container.innerHTML = '';

    mySlots.forEach((slot, i) => {
        const row = document.createElement('div');
        row.className = 'pose-slot-row';

        // 番号バッジ
        const badge = document.createElement('div');
        badge.className = 'slot-num-badge';
        badge.textContent = i + 1;

        // 適用ボタン（＝プリセットボタン）
        const applyBtn = document.createElement('button');
        applyBtn.className = 'slot-apply-btn has-data';
        applyBtn.dataset.slotIdx = i;
        // 表情がONのポーズには、絵文字バッジを付けて一目で分かるようにする
        const exprBadge = slot.expressionEnabled
            ? ' ' + ((EXPRESSION_PRESETS.find(p => p.key === slot.expressionKey) || {}).emoji || '😊')
            : '';
        applyBtn.textContent = slot.name + exprBadge;
        applyBtn.addEventListener('click', () => {
            document.querySelectorAll('.slot-apply-btn').forEach(b => b.classList.remove('active'));
            applyBtn.classList.add('active');
            applyPoseSnapshot(slot.poseSnapshot);
            applyFaceExpression(getEffectiveExpression(slot)); // このポーズ専用の表情（OFFならデフォルト表情）を反映
            activeSlotIndex = i; // このプリセットを編集したら自動保存される
            seqFrames = null;
            seqOnComplete = null;
            setCommandPlayingUI(false); // プリセットを選んだらコマンド再生は打ち切り扱いにする
            // コマンドのactiveも外す
            document.querySelectorAll('.cmd-btn').forEach(b => b.classList.remove('active'));
            // 「🎮 ポージング」タブ側の表情エディタも、選んだポーズに合わせて同期する
            syncAllExpressionEditors();
        });

        // 編集ボタン（✏️）— 名前変更・リセット
        const editBtn = document.createElement('button');
        editBtn.className = 'slot-edit-btn';
        editBtn.textContent = '✏️';
        editBtn.title = `プリセット${i+1}を編集`;
        editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            openSlotEditPopup(i);
        });

        row.append(badge, applyBtn, editBtn);
        container.appendChild(row);
    });

    // 最初のスロットをactive
    const first = container.querySelector('.slot-apply-btn');
    if (first) first.classList.add('active');
}

function showSlotStatus(msg) {
    const el = document.getElementById('saveLoadStatus');
    if (!el) return;
    el.textContent = msg;
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.textContent = ''; }, 2500);
}

// ── スロット名編集ポップアップ ───────────────────────────────
function openSlotEditPopup(slotIdx) {
    slotEditTarget = slotIdx;
    const popup   = document.getElementById('slot-edit-popup');
    const overlay = document.getElementById('slot-popup-overlay');
    const input   = document.getElementById('slot-name-input');
    if (!popup || !overlay || !input) return;
    input.value = mySlots[slotIdx].name;
    popup.classList.add('open');
    overlay.classList.add('open');
    if (window._exprEditors) window._exprEditors.popup.sync();
    setTimeout(() => input.focus(), 50);
}

// ============================================================
// 表情エディタ（共通ロジック）
// ------------------------------------------------------------
// 「🗃️ ポーズ格納庫」の✏️編集ポップアップと「🎮 ポージング」タブの
// 両方に、同じ操作性の表情エディタ（ON/OFFトグル＋8プリセット）を置く。
// 編集対象スロットの取得方法だけが呼び出し元ごとに異なるので、
// getTargetIndex() 関数で切り替える：
//   ・ポップアップ側 → 今開いているスロット(slotEditTarget)
//   ・ポージングタブ側 → 今アクティブなスロット(activeSlotIndex)
//     （体のポージング編集も同じactiveSlotIndexに自動保存されるため、
//      「今動かしている体」と「今設定する表情」が常に同じポーズを指す）
// ============================================================
function createExpressionEditorUI({ toggleId, buttonsId, statusId, getTargetIndex }) {
    const toggle    = document.getElementById(toggleId);
    const container = document.getElementById(buttonsId);
    const statusEl  = statusId ? document.getElementById(statusId) : null;
    if (!toggle || !container) return { sync(){} };

    // プリセットボタンは初回に1度だけ生成する
    container.innerHTML = '';
    EXPRESSION_PRESETS.forEach(preset => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'slot-expr-btn';
        btn.dataset.key = preset.key;
        btn.title = preset.usage;
        btn.innerHTML = `<span class="expr-emoji">${preset.emoji}</span><span class="expr-label">${preset.label}</span>`;
        btn.addEventListener('click', () => {
            const idx = getTargetIndex();
            if (idx < 0 || !mySlots[idx]) return;
            const slot = mySlots[idx];
            // ★必須ルール：プリセットの内容はディープコピーして持たせる（同じ参照を共有しない）
            slot.expressionEnabled = true;
            slot.expressionKey     = preset.key;
            slot.expression        = cloneExpression(preset);
            saveSlots(mySlots);
            syncAllExpressionEditors();
            buildSlotButtons(); // 格納庫の表情バッジも更新
            // 今まさに表示中のポーズなら、その場でプレビューに反映する
            if (idx === activeSlotIndex) applyFaceExpression(getEffectiveExpression(slot));
        });
        container.appendChild(btn);
    });

    toggle.addEventListener('change', (e) => {
        const idx = getTargetIndex();
        if (idx < 0 || !mySlots[idx]) return;
        const slot = mySlots[idx];
        slot.expressionEnabled = (e.target.value === 'true');
        saveSlots(mySlots);
        syncAllExpressionEditors();
        buildSlotButtons();
        if (idx === activeSlotIndex) applyFaceExpression(getEffectiveExpression(slot));
    });

    function sync() {
        const idx = getTargetIndex();
        const slot = (idx >= 0) ? mySlots[idx] : null;
        const enabled = !!slot;
        toggle.disabled = !enabled;
        toggle.value = slot ? (slot.expressionEnabled ? 'true' : 'false') : 'false';
        container.style.opacity = (enabled && slot.expressionEnabled) ? '1' : '0.45';
        container.style.pointerEvents = (enabled && slot.expressionEnabled) ? '' : 'none';
        container.querySelectorAll('.slot-expr-btn').forEach(b => {
            b.disabled = !enabled;
            b.classList.toggle('active', enabled && slot.expressionEnabled && b.dataset.key === slot.expressionKey);
        });
        if (statusEl) {
            if (enabled) {
                statusEl.textContent = `「${slot.name}」の表情を編集中`;
                statusEl.classList.remove('inactive');
            } else {
                statusEl.textContent = '👉 まず🗃️ポーズ格納庫でポーズを選んでください';
                statusEl.classList.add('inactive');
            }
        }
    }

    return { sync };
}

// 両方の表情エディタをまとめて同期する
function syncAllExpressionEditors() {
    if (!window._exprEditors) return;
    window._exprEditors.popup.sync();
    window._exprEditors.posing.sync();
}
window.syncAllExpressionEditors = syncAllExpressionEditors;

window._exprEditors = {
    popup: createExpressionEditorUI({
        toggleId: 'slot-expr-toggle', buttonsId: 'slot-expr-buttons', statusId: null,
        getTargetIndex: () => slotEditTarget,
    }),
    posing: createExpressionEditorUI({
        toggleId: 'posing-expr-toggle', buttonsId: 'posing-expr-buttons', statusId: 'posing-expr-status',
        getTargetIndex: () => activeSlotIndex,
    }),
};
syncAllExpressionEditors();

function closeSlotEditPopup() {
    document.getElementById('slot-edit-popup').classList.remove('open');
    document.getElementById('slot-popup-overlay').classList.remove('open');
    slotEditTarget = -1;
}

document.getElementById('slot-popup-ok').addEventListener('click', () => {
    if (slotEditTarget < 0) return;
    const name = document.getElementById('slot-name-input').value.trim();
    if (name) {
        mySlots[slotEditTarget].name = name;
        mySlots[slotEditTarget].isDefault = false;
    }
    saveSlots(mySlots);
    buildSlotButtons();
    closeSlotEditPopup();
});

document.getElementById('slot-popup-cancel').addEventListener('click', closeSlotEditPopup);
document.getElementById('slot-popup-overlay').addEventListener('click', closeSlotEditPopup);

// 🔄 初期ポーズに戻すボタン
document.getElementById('slot-popup-reset').addEventListener('click', () => {
    if (slotEditTarget < 0) return;
    const i     = slotEditTarget;
    const def   = defaultSlots()[i];
    mySlots[i]  = def;
    saveSlots(mySlots);
    buildSlotButtons();
    // 初期ポーズ（表情含む）を即適用
    applyPoseSnapshot(def.poseSnapshot);
    applyFaceExpression(getEffectiveExpression(def));
    activeSlotIndex = i;
    syncAllExpressionEditors();
    showSlotStatus(`プリセット${i+1}を初期ポーズに戻しました`);
    closeSlotEditPopup();
});

