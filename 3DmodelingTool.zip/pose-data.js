// ============================================================
// 「ドラゴンバスター」勇者アニメ用 単体ポーズ（シーケンスから参照）
// ------------------------------------------------------------
// 要望の8アニメーションを構成する13個のキーポーズ。
// 複数ポーズが必要なアニメーションは _A/_MID/_B、_READY/_WINDUP/_SLASH
// のように分割し、POSES配列（=ポーズ格納庫のプリセット/GLBクリップ）と
// COMMANDS配列（=ツール内プレビュー用の連続再生）の両方から参照することで
// 数値の二重管理を避けている。
//   1.😊 待機            → POSE_IDLE
//   2.🏃 疾走             → POSE_SPRINT_A / _MID / _B（3ポーズの往復ループ）
//   3.⚔ 大剣構え          → POSE_GS_READY
//   4.⚔ 大剣攻撃          → POSE_GS_WINDUP（振りかぶり）→ POSE_GS_SLASH（斬り下ろし）
//   5.🦘 ジャンプ          → POSE_JUMP_CROUCH（しゃがみ）→ POSE_JUMP_AIR（空中）
//   6.✨ 魔法アイテム使用  → POSE_MAGIC_RAISE（構え）→ POSE_MAGIC_CAST（発動）
//   7.😵 ダメージ          → POSE_DAMAGE
//   8.🏆 勝利             → POSE_VICTORY
// ============================================================
const POSE_IDLE = {
    head: { rx: -0.05, ry: 0.04, rz: 0 },
    arms: [
        { root: { rx:  0.05, ry: 0, rz:  0.12 }, joint: { rx: -0.1,  rz: 0 } },
        { root: { rx:  0.05, ry: 0, rz: -0.15 }, joint: { rx: -0.15, rz: 0 } },
    ],
    legs: [
        { root: { rx:  0.03, rz:  0.06 }, joint: { rx: 0.05 } },
        { root: { rx: -0.02, rz: -0.06 }, joint: { rx: 0.03 } },
    ],
    swordTiltX: -0.4, // 剣先を下げてリラックスして構える
};
const POSE_SPRINT_A = { // 左足が前に出た接地ポーズ
    head: { rx: -0.12, ry: 0, rz: 0 },
    arms: [
        { root: { rx: -0.45, ry: 0, rz:  0.18 }, joint: { rx: -0.45, rz: 0 } },
        { root: { rx:  0.55, ry: 0, rz: -0.18 }, joint: { rx: -0.5,  rz: 0 } },
    ],
    legs: [
        { root: { rx:  0.65, rz:  0.06 }, joint: { rx: 0.85 } },
        { root: { rx: -0.45, rz: -0.06 }, joint: { rx: 0.15 } },
    ],
    swordTiltX: -0.25,
};
const POSE_SPRINT_MID = { // 両足が体の下でそろう通過姿勢
    head: { rx: -0.12, ry: 0, rz: 0 },
    arms: [
        { root: { rx: 0.05, ry: 0, rz:  0.18 }, joint: { rx: -0.5, rz: 0 } },
        { root: { rx: 0.08, ry: 0, rz: -0.18 }, joint: { rx: -0.5, rz: 0 } },
    ],
    legs: [
        { root: { rx: 0.15, rz:  0.06 }, joint: { rx: 0.5 } },
        { root: { rx: 0.12, rz: -0.06 }, joint: { rx: 0.5 } },
    ],
    swordTiltX: -0.25,
};
const POSE_SPRINT_B = { // 右足が前に出た接地ポーズ（Aの左右反転）
    head: { rx: -0.12, ry: 0, rz: 0 },
    arms: [
        { root: { rx:  0.55, ry: 0, rz:  0.18 }, joint: { rx: -0.5,  rz: 0 } },
        { root: { rx: -0.45, ry: 0, rz: -0.18 }, joint: { rx: -0.45, rz: 0 } },
    ],
    legs: [
        { root: { rx: -0.45, rz:  0.06 }, joint: { rx: 0.15 } },
        { root: { rx:  0.65, rz: -0.06 }, joint: { rx: 0.85 } },
    ],
    swordTiltX: -0.25,
};
const POSE_GS_READY = { // 大剣を両手持ちの構えで低く腰を落とす
    head: { rx: -0.05, ry: -0.1, rz: 0 },
    arms: [
        { root: { rx: -0.15, ry:  0.15, rz:  0.65 }, joint: { rx: -0.55, rz: 0 } },
        { root: { rx: -0.25, ry: -0.05, rz: -0.75 }, joint: { rx: -0.6,  rz: 0 } },
    ],
    legs: [
        { root: {  rx: 0.4, rz:  0.12 }, joint: { rx: 0.3 } },
        { root: { rx: -0.3, rz: -0.12 }, joint: { rx: 0.2 } },
    ],
    swordTiltX: 0.7, // 切っ先を前方やや上に構える
};
const POSE_GS_WINDUP = { // 大剣を頭上高くに振りかぶる
    head: { rx: -0.2, ry: -0.05, rz: 0 },
    arms: [
        { root: {  rx: 0.3, ry: 0.1,   rz:  0.35 }, joint: { rx: -0.25, rz: 0 } },
        { root: { rx: -0.9, ry: -0.25, rz: -2.0  }, joint: { rx: -0.65, rz: 0 } },
    ],
    legs: [
        { root: {  rx: 0.45, rz:  0.1 }, joint: { rx: 0.3  } },
        { root: { rx: -0.2,  rz: -0.1 }, joint: { rx: 0.15 } },
    ],
    swordTiltX: 1.5, // 頭上高くに振りかぶった状態
};
const POSE_GS_SLASH = { // 大剣を体の前へ斜めに振り下ろした瞬間
    head: { rx: 0.15, ry: 0.2, rz: 0 },
    arms: [
        { root: { rx: 0.1, ry: 0,    rz: 0.2 }, joint: { rx: -0.1, rz: 0 } },
        { root: { rx: 1.0, ry: 0.35, rz: 0.3 }, joint: { rx: -0.2, rz: 0 } },
    ],
    legs: [
        { root: { rx: -0.15, rz:  0.12 }, joint: { rx: 0.1  } },
        { root: { rx:  0.4,  rz: -0.12 }, joint: { rx: 0.35 } },
    ],
    swordTiltX: -1.4, // 振り下ろし後で切っ先が下を向く
};
const POSE_JUMP_CROUCH = { // 跳躍直前の深いしゃがみ（踏み切り準備）
    head: { rx: 0.1, ry: 0, rz: 0 },
    arms: [
        { root: { rx: -0.5,  ry: 0, rz:  0.15 }, joint: { rx: -0.3,  rz: 0 } },
        { root: { rx: -0.55, ry: 0, rz: -0.15 }, joint: { rx: -0.35, rz: 0 } },
    ],
    legs: [
        { root: { rx: 0.55, rz:  0.1 }, joint: { rx: 1.1 } },
        { root: { rx: 0.55, rz: -0.1 }, joint: { rx: 1.1 } },
    ],
    swordTiltX: -0.5,
};
const POSE_JUMP_AIR = { // 跳躍の頂点、脚を非対称に流した空中姿勢
    head: { rx: -0.15, ry: 0, rz: 0 },
    arms: [
        { root: { rx: -0.8, ry: 0, rz:  0.3 }, joint: { rx: -0.2,  rz: 0 } },
        { root: { rx: -0.7, ry: 0, rz: -0.3 }, joint: { rx: -0.15, rz: 0 } },
    ],
    legs: [
        { root: {  rx: 0.3,  rz:  0.08 }, joint: { rx: 0.8  } },
        { root: { rx: -0.35, rz: -0.08 }, joint: { rx: 0.25 } },
    ],
    swordTiltX: 0.3,
};
const POSE_MAGIC_RAISE = { // 左手の魔法アイテムを頭上へ掲げる
    head: { rx: -0.35, ry: 0, rz: 0 },
    arms: [
        { root: { rx: -1.4, ry: 0, rz:  0.15 }, joint: { rx: -0.1, rz: 0 } },
        { root: { rx:  0.15, ry: 0, rz: -0.25 }, joint: { rx: -0.2, rz: 0 } },
    ],
    legs: [
        { root: {  rx: 0.05, rz:  0.08 }, joint: { rx: 0.05 } },
        { root: { rx: -0.05, rz: -0.08 }, joint: { rx: 0.05 } },
    ],
    swordTiltX: -0.6,
};
const POSE_MAGIC_CAST = { // 魔法発動の瞬間、上体を反らして両腕を開く
    head: { rx: -0.45, ry: 0, rz: 0.05 },
    arms: [
        { root: { rx: -1.5, ry: -0.2, rz:  0.5 }, joint: { rx: -0.05, rz: 0 } },
        { root: { rx: -0.3, ry:  0.15, rz: -0.6 }, joint: { rx: -0.15, rz: 0 } },
    ],
    legs: [
        { root: {  rx: 0.1,  rz:  0.1 }, joint: { rx: 0.1  } },
        { root: { rx: -0.15, rz: -0.1 }, joint: { rx: 0.15 } },
    ],
    swordTiltX: -0.4,
};
const POSE_DAMAGE = { // 被弾のけぞり、剣が力なく下がる
    head: { rx: 0.35, ry: 0.15, rz: 0.1 },
    arms: [
        { root: { rx: 0.4, ry: 0.1, rz:  0.5 }, joint: { rx: -0.9, rz: 0 } },
        { root: { rx: 0.3, ry: 0,   rz: -0.35 }, joint: { rx: -0.3, rz: 0 } },
    ],
    legs: [
        { root: { rx: -0.2, rz:  0.15 }, joint: { rx: 0.35 } },
        { root: {  rx: 0.25, rz: -0.05 }, joint: { rx: 0.1  } },
    ],
    swordTiltX: -0.9,
};
const POSE_VICTORY = { // 大剣を天に掲げて勝ちどきを上げる
    head: { rx: -0.3, ry: 0, rz: 0 },
    arms: [
        { root: { rx: -0.1,  ry: -0.2, rz:  0.45 }, joint: { rx: -0.15, rz: 0 } },
        { root: { rx: -0.35, ry: 0,    rz: -2.6  }, joint: { rx: -0.1,  rz: 0 } },
    ],
    legs: [
        { root: { rx: 0, rz:  0.08 }, joint: { rx: 0 } },
        { root: { rx: 0, rz: -0.08 }, joint: { rx: 0 } },
    ],
    swordTiltX: 1.3, // 剣を高々と天に掲げる
};

// ============================================================
// Quaternionユーティリティ（ポージング系の回転処理はすべてここを経由する）
// ------------------------------------------------------------
// 各ボーンの角度は、これまで通り
//   rx = 前後（Pitch） / ry = 左右（Yaw） / rz = ひねり（Roll）
// という3つの値で入力・保存されるが、実際にボーンへ適用する際は
// bone.rotation.x/y/z への個別代入ではなく、Quaternionとして合成してから
// bone.quaternion へ反映する。これにより
//   ・ジンバルロックを避けられる
//   ・SLERPによる滑らかなポーズ間補間ができる
//   ・GLB出力（quaternionトラック）とそのまま整合する
// というメリットが得られる。
//
// 合成順序は「Yaw（左右）→ Pitch（前後）→ Roll（ひねり）」を基本とする。
// Three.jsのEuler/Quaternionで 'YXZ' オーダーを指定すると、内部的に
//   q = qYaw（Y軸） × qPitch（X軸） × qRoll（Z軸）
// の順で合成されるため、この関数群では一貫して 'YXZ' を使用する。
// ============================================================
const POSE_ROTATION_ORDER = 'YXZ'; // Yaw→Pitch→Rollの順で合成されるEulerオーダー
const _poseWorkEuler = new THREE.Euler(0, 0, 0, POSE_ROTATION_ORDER); // 使い回し用ワーク変数（毎フレーム確保しない）

// 前後(rx=Pitch) / 左右(ry=Yaw) / ひねり(rz=Roll) の角度(ラジアン)からQuaternionを生成する。
// target を渡すと、そのQuaternionに直接書き込む（呼び出し側で使い回してGCコストを避けられる）。
function anglesToQuaternion(rx = 0, ry = 0, rz = 0, target = new THREE.Quaternion()) {
    _poseWorkEuler.set(rx, ry, rz, POSE_ROTATION_ORDER);
    return target.setFromEuler(_poseWorkEuler);
}

// Quaternionから、保存・エクスポート用の rx(Pitch)/ry(Yaw)/rz(Roll) 角度(ラジアン)を逆算する。
function quaternionToAngles(q) {
    _poseWorkEuler.setFromQuaternion(q, POSE_ROTATION_ORDER);
    return { rx: _poseWorkEuler.x, ry: _poseWorkEuler.y, rz: _poseWorkEuler.z };
}

// 角度(ラジアン)をQuaternionに変換してオブジェクトへ直接適用するヘルパー。
// bone.rotation.x/y/z の個別代入の代わりに、常にこの関数を通して適用する。
function setBoneAnglesAsQuaternion(obj, rx = 0, ry = 0, rz = 0) {
    if (!obj) return;
    anglesToQuaternion(rx, ry, rz, obj.quaternion);
}

// 2つの姿勢（{rx,ry,rz}、ラジアン）のQuaternionをSLERPで補間し、そのままボーンへ適用する。
// tickPoseLerpのようにフレーム毎に呼ばれる箇所で使うため、作業用Quaternionは使い回す。
const _slerpQFrom = new THREE.Quaternion();
const _slerpQTo   = new THREE.Quaternion();
function slerpBoneAngles(obj, fromAngles, toAngles, t) {
    if (!obj) return;
    anglesToQuaternion(fromAngles?.rx ?? 0, fromAngles?.ry ?? 0, fromAngles?.rz ?? 0, _slerpQFrom);
    anglesToQuaternion(toAngles?.rx   ?? 0, toAngles?.ry   ?? 0, toAngles?.rz   ?? 0, _slerpQTo);
    obj.quaternion.slerpQuaternions(_slerpQFrom, _slerpQTo, t);
}

// ポーズ定義（「ドラゴンバスター」勇者アニメ向けプリセット／ポーズ格納庫＝GLBクリップ化される）
// 各値は rotation (x=Pitch, y=Yaw, z=Roll) in radians
// arms[0]=左腕(盾側), arms[1]=右腕(剣側) / legs[0]=左脚, legs[1]=右脚
// root=肩/股関節, joint=肘/膝
// ※ 数値の実体は上の POSE_xxx 定数側にあり、ここではラベルを付けて展開するだけ
//   （複数ポーズで1アニメーションを構成するものは、名前に工程を添えて分けている）
const POSES = [
    { label: '😊 待機',                     ...POSE_IDLE },
    { label: '🏃 疾走・右足着地',           ...POSE_SPRINT_A },
    { label: '🏃 疾走・中間（両足そろう）', ...POSE_SPRINT_MID },
    { label: '🏃 疾走・左足着地',           ...POSE_SPRINT_B },
    { label: '⚔️ 大剣構え',                 ...POSE_GS_READY },
    { label: '⚔️ 大剣攻撃・振りかぶり',     ...POSE_GS_WINDUP },
    { label: '⚔️ 大剣攻撃・斬り下ろし',     ...POSE_GS_SLASH },
    { label: '🦘 ジャンプ・しゃがみ',       ...POSE_JUMP_CROUCH },
    { label: '🦘 ジャンプ・空中',           ...POSE_JUMP_AIR },
    { label: '✨ 魔法・構え',                ...POSE_MAGIC_RAISE },
    { label: '✨ 魔法・発動',                ...POSE_MAGIC_CAST },
    { label: '😵 ダメージ',                  ...POSE_DAMAGE },
    { label: '🏆 勝利',                      ...POSE_VICTORY },
];

// ============================================================
// コマンド定義（複数ポーズで構成するアニメーションのツール内プレビュー用シーケンス）
// 単一ポーズで完結する 待機／大剣構え／ダメージ／勝利 は
// 上の「ポーズ格納庫」ボタン1つで確認できるため、ここには含めていない。
// ============================================================
const COMMANDS = [
    {
        label: '🏃 疾走ループ',
        isSequence: true,
        frames: [
            { pose: POSE_SPRINT_A,   duration: 0.18 },
            { pose: POSE_SPRINT_MID, duration: 0.15 },
            { pose: POSE_SPRINT_B,   duration: 0.18 },
            { pose: POSE_SPRINT_MID, duration: 0.15 },
            { pose: POSE_SPRINT_A,   duration: 0.18 },
            { pose: POSE_SPRINT_MID, duration: 0.15 },
            { pose: POSE_SPRINT_B,   duration: 0.18 },
            { pose: POSE_IDLE,       duration: 0.4  },
        ],
    },
    {
        label: '⚔️ 大剣攻撃',
        isSequence: true,
        frames: [
            { pose: POSE_GS_READY,  duration: 0.3  },
            { pose: POSE_GS_WINDUP, duration: 0.35 },
            { pose: POSE_GS_SLASH,  duration: 0.25 },
            { pose: POSE_GS_READY,  duration: 0.4  },
            { pose: POSE_IDLE,      duration: 0.5  },
        ],
    },
    {
        label: '🦘 ジャンプ',
        isSequence: true,
        frames: [
            { pose: POSE_IDLE,        duration: 0.2  },
            { pose: POSE_JUMP_CROUCH, duration: 0.25 },
            { pose: POSE_JUMP_AIR,    duration: 0.45 },
            { pose: POSE_JUMP_CROUCH, duration: 0.2  },
            { pose: POSE_IDLE,        duration: 0.4  },
        ],
    },
    {
        label: '✨ 魔法アイテム使用',
        isSequence: true,
        frames: [
            { pose: POSE_IDLE,        duration: 0.2  },
            { pose: POSE_MAGIC_RAISE, duration: 0.5  },
            { pose: POSE_MAGIC_CAST,  duration: 0.5  },
            { pose: POSE_MAGIC_RAISE, duration: 0.35 },
            { pose: POSE_IDLE,        duration: 0.5  },
        ],
    },
];

let currentPose = POSES[0];
let poseTarget  = null;   // 補間目標
let poseFrom    = null;   // 補間元
let poseT       = 1.0;    // 0→1 の補間進行度（1=完了）
const POSE_LERP_SPEED = 3.5; // 大きいほど速い

function lerp(a, b, t) { return a + (b - a) * t; }

// ポーズを補間適用する（animateから毎フレーム呼ぶ）
function tickPoseLerp(dt) {
    if (poseT >= 1.0 || !poseTarget || !poseFrom) return;
    poseT = Math.min(poseT + dt * POSE_LERP_SPEED, 1.0);
    const t = poseT < 1 ? poseT * poseT * (3 - 2 * poseT) : 1; // smoothstep

    const p = animatedParts;
    if (!p.arms.length) return;

    // 頭：QuaternionをSLERPで補間して適用する。
    // （rx/ry/rzを個別にlerpする方式は、角度が大きい時にジンバルロック付近で
    //   不自然な軌道になることがあるため、球面線形補間に置き換えている）
    if (p.head) slerpBoneAngles(p.head, poseFrom.head, poseTarget.head, t);

    // 腕
    p.arms.forEach((arm, i) => {
        const f = poseFrom.arms[i], g = poseTarget.arms[i];
        slerpBoneAngles(arm.root,  f.root,  g.root,  t);
        slerpBoneAngles(arm.joint, f.joint, g.joint, t);
        slerpBoneAngles(arm.wrist, f.wrist, g.wrist, t);
    });
    // 脚
    p.legs.forEach((leg, i) => {
        const f = poseFrom.legs[i], g = poseTarget.legs[i];
        slerpBoneAngles(leg.root,  f.root,  g.root,  t);
        slerpBoneAngles(leg.joint, f.joint, g.joint, t);
    });
    // 剣（持っている場合のみ）：ポーズごとのチルトをベース回転に加算
    if (p.sword) {
        const tiltFrom = poseFrom.swordTiltX ?? 0;
        const tiltTo   = poseTarget.swordTiltX ?? 0;
        const tilt = lerp(tiltFrom, tiltTo, t);
        p.sword.rotation.x = SWORD_BASE_ROTATION.x + tilt;
    }
    if (poseT >= 1.0 && window._poseEditApplyAfterPose) window._poseEditApplyAfterPose();
}

// 現在の Quaternion をスナップショット（rx/ry/rzのオイラー角相当に逆変換して従来の形式を維持）
function snapshotCurrentRotations() {
    const p = animatedParts;
    if (!p.arms.length) return null;
    // ボーンのQuaternionから前後(Pitch)/左右(Yaw)/ひねり(Roll)角度(ラジアン)を取り出すヘルパー
    const boneToAngles = (obj) => obj ? quaternionToAngles(obj.quaternion) : { rx: 0, ry: 0, rz: 0 };
    return {
        head: boneToAngles(p.head),
        arms: p.arms.map(arm => {
            const root = boneToAngles(arm.root), joint = boneToAngles(arm.joint), wrist = boneToAngles(arm.wrist);
            return {
                root:  { rx: root.rx,  ry: root.ry,  rz: root.rz  },
                joint: { rx: joint.rx, rz: joint.rz },
                wrist: { rx: wrist.rx, ry: wrist.ry, rz: wrist.rz },
            };
        }),
        legs: p.legs.map(leg => {
            const root = boneToAngles(leg.root), joint = boneToAngles(leg.joint);
            return {
                root:  { rx: root.rx, rz: root.rz },
                joint: { rx: joint.rx },
            };
        }),
        swordTiltX: p.sword ? (p.sword.rotation.x - SWORD_BASE_ROTATION.x) : 0,
    };
}

// ポーズを切り替える（補間開始）
window.applyPose = function(pose) {
    currentPose = pose;
    poseFrom   = snapshotCurrentRotations() || pose;
    poseTarget = pose;
    poseT      = 0;
    // degテーブルをこのポーズのスナップショット値に同期しておく
    if (window._poseEditSyncDeg && window.poseDefToSnapshot) {
        window._poseEditSyncDeg(window.poseDefToSnapshot(pose));
    }
};
