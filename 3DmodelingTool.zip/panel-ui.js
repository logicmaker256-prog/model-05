        // ドロップダウンのプリセット色を選んだ時の処理（肌・目・髪）
        // カスタムカラーピッカーの値も同時に同期する
        function setSkinPreset(hexColor) {
            if (hexColor === 'custom') return; // disabled optionなので実際には来ない
            document.getElementById('bodyColor').value = hexColor;
            characterData.bodyColor = hexColor;
            createCharacter(characterData);
        }

        function setEyePreset(hexColor) {
            if (hexColor === 'custom') return;
            document.getElementById('eyeColor').value = hexColor;
            characterData.eyeColor = hexColor;
            createCharacter(characterData);
        }

        function setHairPreset(hexColor) {
            if (hexColor === 'custom') return;
            document.getElementById('hairColor').value = hexColor;
            characterData.hairColor = hexColor;
            createCharacter(characterData);
        }

        function setSwordType(type) {
            characterData.swordType = type;
            createCharacter(characterData);
        }

        function setHasShield(wear) {
            characterData.hasShield = wear;
            createCharacter(characterData);
        }

        // 軽装プレートアーマー：ヘルメット（頭装備）
        function setHasHelmet(wear) {
            const showPlate = wear || characterData.topWear === 'armor';
            document.getElementById('plateColorGroup').style.display = showPlate ? '' : 'none';
            document.getElementById('plateTrimColorGroup').style.display = showPlate ? '' : 'none';
            characterData.hasHelmet = wear;
            createCharacter(characterData);
        }

        function setWearBoots(wear) {
            document.getElementById('bootsColorGroup').style.display = wear ? '' : 'none';
            const color = document.getElementById('bootsColor').value;
            characterData.bootsColor = wear ? color : 'none';
            createCharacter(characterData);
        }

        // 下半身装備切替（なし / ズボン / スカート / キュロット / ロングスカート）── 同時装備は禁止
        function setBottomWear(type) {
            // 色UI表示切替
            document.getElementById('pantsColorGroup').style.display = (type === 'pants') ? '' : 'none';
            // ロングスカートは既存の「スカート」本体をそのまま使う（色ピッカーも共用）
            document.getElementById('skirtColorGroup').style.display = (type === 'skirt' || type === 'culotte' || type === 'longskirt') ? '' : 'none';
            characterData.bottomWear = type;
            createCharacter(characterData);
        }

        function setTopWear(type) {
            // 色ピッカーの表示切替
            document.getElementById('shirtColorGroup').style.display = (type === 'shirt') ? '' : 'none';
            const showPlate = (type === 'armor') || characterData.hasHelmet;
            document.getElementById('plateColorGroup').style.display = showPlate ? '' : 'none';
            document.getElementById('plateTrimColorGroup').style.display = showPlate ? '' : 'none';
            characterData.topWear = type;
            createCharacter(characterData);
        }

        // ============================================================
        // 統合メニューパネル：開閉／メインタブ／カテゴリ アコーディオン
        // ============================================================
        const appHeader  = document.getElementById('appPanelHeader');
        const appContent = document.getElementById('appPanelContent');
        const appIcon    = document.getElementById('appToggleIcon');
        let appPanelOpen = true;
        let activeMainTab = 'chara';

        // ポージングタブの表示状態が変わった時にドラッグギズモの表示を連動させるためのフック。
        // ポーズ編集パネルのIIFE内でwindow.__setPosingActiveとして実体が定義される。
        function notifyPosingVisibility() {
            const posingVisible = appPanelOpen && activeMainTab === 'posing';
            if (typeof window.__setPosingActive === 'function') {
                window.__setPosingActive(posingVisible);
            }
        }

        // ヘッダータップでパネル全体を開閉
        appHeader.addEventListener('click', () => {
            appContent.classList.toggle('is-closed');
            appPanelOpen = !appContent.classList.contains('is-closed');
            appIcon.style.transform = appPanelOpen ? 'rotate(0deg)' : 'rotate(-90deg)';
            notifyPosingVisibility();
        });

        // メインタブ（キャラ／ポージング／ポーズ格納庫／ファイル）切り替え
        document.querySelectorAll('.main-tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                activeMainTab = btn.dataset.tab;
                document.querySelectorAll('.main-tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));
                document.getElementById('tab-' + activeMainTab).classList.add('active');
                notifyPosingVisibility();
                // ポージングタブに来たとき、体の編集対象と表情エディタの表示を最新状態に同期する
                if (activeMainTab === 'posing' && window.syncAllExpressionEditors) window.syncAllExpressionEditors();
            });
        });

        // キャラタブ内のカテゴリ（体型／顔形／髪／衣装／小道具）アコーディオン
        document.querySelectorAll('.menu-category-header').forEach(hdr => {
            hdr.addEventListener('click', () => {
                const body = hdr.nextElementSibling;
                body.classList.toggle('is-closed');
                hdr.classList.toggle('open', !body.classList.contains('is-closed'));
            });
        });

        // 初期状態：ポージングタブは非表示なのでギズモも隠す
        notifyPosingVisibility();

        // 終了
        document.getElementById('exitBtn').addEventListener('click', () => {
            if (!confirm('作業を終了しますか？\n保存していない変更は失われます。')) return;
            window.close();
            setTimeout(() => {
                alert('ブラウザの仕様上、タブを自動で閉じることができませんでした。\nこのままタブを閉じて終了してください。');
            }, 300);
        });
