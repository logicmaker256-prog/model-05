// ============================================================
// createTShirt() — 服生成関数
// ============================================================
// 【設計方針】
//   ・body（素体）と完全分離。新しいMesh/Geometry/Materialで構成
//   ・clothesGroup を characterGroup の子として追加
//   ・胴体：頂点変形で胸部を前方に押し出し自然な膨らみを表現
//   ・袖：左右別Meshで肩関節の子にする（腕回転に追従）
//   ・将来「鎧」「ローブ」等を追加するときはこの関数を参考に
// ============================================================
function createTShirt(color, targetGroup, data) {

    // ── マテリアル ──────────────────────────────────────────
    const shirtMat = new THREE.MeshLambertMaterial({
        color: color,
        side: THREE.DoubleSide,
    });

    // ── clothesGroup：服全体をまとめるグループ ──────────────
    const clothesGroup = new THREE.Group();
    clothesGroup.name = 'clothesGroup';

    // ============================================================
    // 【胴体 上部】半楕円ドーム＋首穴
    // 設計図①: 胸部楕円の上側を微増した半楕円スキン
    // 設計図②: 中央に首球体半径(neckR=0.27)の穴
    // ============================================================
    // chest上端y≈2.42、ドーム半径≈0.68（肩をカバー）
    const domeY    = 2.10;  // ドーム底面（首が見えるよう下げる）
    const domeR    = 0.68;  // 横半径（肩をカバー）
    const domeH    = 0.38;  // ドームの高さ（半楕円）
    const neckHole = 0.30;  // 首穴半径（neckR=0.27より少し大きめ）
    const segments = 32;

    // SphereGeometryの上半分を使ってドームを作る
    // phiStart=0, phiLength=π → 上半球
    // 首穴：thetaStart=arcsin(neckHole/domeR)で中央を開ける
    const domeGeo = new THREE.SphereGeometry(
        domeR,      // radius
        segments,   // widthSegments
        16,         // heightSegments
        0,          // phiStart
        Math.PI * 2,// phiLength（全周）
        Math.asin(neckHole / domeR), // thetaStart：首穴の角度から始める
        Math.PI / 2 // thetaLength：上半球のみ
    );
    // Y方向をdomeH/domeRで圧縮して半楕円に
    // Z方向を0.72倍で前後を薄く
    const domePos = domeGeo.attributes.position;
    for (let i = 0; i < domePos.count; i++) {
        domePos.setY(i, domePos.getY(i) * (domeH / domeR));
        domePos.setZ(i, domePos.getZ(i) * 0.72);
    }
    domePos.needsUpdate = true;
    domeGeo.computeVertexNormals();

    const dome = new THREE.Mesh(domeGeo, shirtMat);
    dome.name = 'shirtDome';
    dome.position.y = domeY;
    clothesGroup.add(dome);

    // 首穴の縁取り（TorusGeometry）
    const collarGeo = new THREE.TorusGeometry(neckHole, 0.035, 8, 32);
    const collar = new THREE.Mesh(collarGeo, shirtMat);
    collar.name = 'shirtCollar';
    collar.rotation.x = Math.PI / 2; // 水平に寝かせる
    collar.position.y = domeY + domeH * 0.95;
    clothesGroup.add(collar);

    // ============================================================
    // 【胴体 下部】ドーム底面(y=domeY)から股下(y=0.65)まで円錐台
    // 設計図③: 楕円端から股下まで円錐台を伸ばす
    // ============================================================
    const skirtH   = domeY - 0.65;  // ≈1.77
    const skirtGeo = new THREE.CylinderGeometry(
        domeR,        // radiusTop: ドーム底面と同じ半径
        domeR * 0.92, // radiusBottom: 裾は少し絞る
        skirtH,
        segments,
        1,
        true  // openEnded
    );
    // Z方向を0.72倍にして楕円断面
    const skirtPos = skirtGeo.attributes.position;
    for (let i = 0; i < skirtPos.count; i++) {
        skirtPos.setZ(i, skirtPos.getZ(i) * 0.72);
    }
    skirtPos.needsUpdate = true;
    skirtGeo.computeVertexNormals();

    const skirt = new THREE.Mesh(skirtGeo, shirtMat);
    skirt.name = 'shirtSkirt';
    skirt.position.y = domeY - skirtH / 2;
    clothesGroup.add(skirt);

    // ============================================================
    // 【胸カバー】bustSize連動で胸球体を服色で覆う
    // ① 左右の胸の間を埋める円柱（谷間カバー）
    // ② 左右それぞれ外側を服色球体で覆う
    // chest(y=2.0)の子 bustL/R の位置に合わせる
    // bustL: position(+0.26, 0.15, p), bustR: position(-0.26, 0.15, p)
    // ============================================================
    if (data.bustSize > 0) {
        const b   = data.bustSize;
        const p   = data.bustProtrude;
        const br  = 0.22 * b;       // 胸球体の半径
        const cr  = br * 1.08;      // カバー半径（胸より少し大き目）

        // chestメッシュを探す（y≈2.0）
        let chestMesh = null;
        targetGroup.traverse(obj => {
            if (obj.isMesh && Math.abs(obj.position.y - 2.0) < 0.05
                && !obj.name.startsWith('shirt')) {
                chestMesh = obj;
            }
        });

        if (chestMesh) {
            // ① 谷間円柱：左右胸中心(x=±0.26)の間を埋める
            //    半径=cr、高さ=左右間距離(0.52)、中心x=0
            const bridgeGeo = new THREE.CylinderGeometry(cr, cr, 0.36, 20);
            bridgeGeo.rotateZ(Math.PI / 2); // X方向に横倒し
            const bridge = new THREE.Mesh(bridgeGeo, shirtMat);
            bridge.name = 'bustBridge';
            bridge.position.set(0, -0.05, p);
            chestMesh.add(bridge);
            clothesGroup.userData.bustBridge = bridge;

            // ② 左右それぞれ外側を球体で覆う
            const coverGeoL = new THREE.SphereGeometry(cr, 16, 16);
            const coverL = new THREE.Mesh(coverGeoL, shirtMat);
            coverL.name = 'bustCoverL';
            coverL.position.set(0.17, -0.05, p);
            chestMesh.add(coverL);

            const coverGeoR = new THREE.SphereGeometry(cr, 16, 16);
            const coverR = new THREE.Mesh(coverGeoR, shirtMat);
            coverR.name = 'bustCoverR';
            coverR.position.set(-0.17, -0.05, p);
            chestMesh.add(coverR);

            // clothesGroupに参照を保持（削除時に使用）
            clothesGroup.userData.bustCovers = [bridge, coverL, coverR];
        }
    }

    targetGroup.add(clothesGroup);

    // ============================================================
    // 【袖】左右別Mesh — 肩関節(shoulder)の子として追加
    // 理由：腕の回転アニメーションに自動追従させるため
    // ============================================================
    // shoulderは createArm() 内で characterGroup に add されている
    // ここでは characterGroup の子を走査して肩を探す
    function addSleeve(shoulderMesh, side) {
        // 半袖：短い開口円筒
        const sleeveGeo = new THREE.CylinderGeometry(
            0.24,  // 上端（肩側）：肩関節を余裕を持って覆う
            0.21,  // 下端（腕側）：腕に向かってやや細く
            0.42,  // 長さ
            16, 1, true // openEnded
        );
        // 袖口（下端）をふさぐ円
        const cuffGeo = new THREE.CircleGeometry(0.21, 16);

        const sleeve = new THREE.Mesh(sleeveGeo, shirtMat);
        const cuff   = new THREE.Mesh(cuffGeo, shirtMat);
        sleeve.name = `sleeve_${side}`;
        cuff.name   = `cuff_${side}`;

        // 円筒を腕方向（X軸）に向ける
        sleeve.rotation.z = Math.PI / 2;
        cuff.rotation.z   = Math.PI / 2;

        // 肩関節中心から腕方向にオフセット
        const offsetX = (side === 'L') ? 0.21 : -0.21;
        sleeve.position.set(offsetX, 0, 0);
        cuff.position.set(offsetX * 2, 0, 0);

        shoulderMesh.add(sleeve);
        shoulderMesh.add(cuff);
    }

    // characterGroup 直下の Mesh を走査して肩(y≈2.3)を特定
    targetGroup.children.forEach(child => {
        if (child.isMesh && Math.abs(child.position.y - 2.15) < 0.05) {
            if (child.position.x > 0) {
                addSleeve(child, 'L');
            } else if (child.position.x < 0) {
                addSleeve(child, 'R');
            }
        }
    });

    return clothesGroup; // 参照を返す（削除・切り替え用）
}

// ============================================================
// 軽装プレートアーマー：胸当て（前後一体型）
// ============================================================
// 【設計方針】
//   ・createTShirt()と同じドーム＋胴体円錐台の座標系を流用し、
//     形状は前後がつながった1枚の一体シェルとして生成（前後別パーツにはしない）
//   ・素材だけをLambert(甲冑色)＋金の縁取りに変更し「鎧」らしい質感にする
//   ・胸の膨らみ（bustSize/bustProtrude）にも追従してカバーする
//   ・肩当て・篭手は次のステップで追加するため、袖は作らない
// ============================================================
function createBreastplate(data, targetGroup) {

    const plateColor = data.plateColor || '#d8dce0';
    const trimColor  = data.plateTrimColor || '#d4af37';
    const plateMat = new THREE.MeshLambertMaterial({ color: plateColor, side: THREE.DoubleSide });
    const trimMat  = new THREE.MeshLambertMaterial({ color: trimColor });

    const breastplateGroup = new THREE.Group();
    breastplateGroup.name = 'breastplateGroup';

    // ── 上部：肩をカバーする半楕円ドーム＋首穴（Tシャツと同じ座標系） ──
    const domeY    = 2.10;
    const domeR    = 0.68;
    const domeH    = 0.38;
    const neckHole = 0.30;
    const segments = 32;

    const domeGeo = new THREE.SphereGeometry(
        domeR, segments, 16,
        0, Math.PI * 2,
        Math.asin(neckHole / domeR),
        Math.PI / 2
    );
    const domePos = domeGeo.attributes.position;
    for (let i = 0; i < domePos.count; i++) {
        domePos.setY(i, domePos.getY(i) * (domeH / domeR));
        domePos.setZ(i, domePos.getZ(i) * 0.72);
    }
    domePos.needsUpdate = true;
    domeGeo.computeVertexNormals();

    const dome = new THREE.Mesh(domeGeo, plateMat);
    dome.name = 'breastplateDome';
    dome.position.y = domeY;
    breastplateGroup.add(dome);

    // 首まわりの金縁
    const collarGeo = new THREE.TorusGeometry(neckHole, 0.04, 8, 32);
    const collar = new THREE.Mesh(collarGeo, trimMat);
    collar.name = 'breastplateCollar';
    collar.rotation.x = Math.PI / 2;
    collar.position.y = domeY + domeH * 0.95;
    breastplateGroup.add(collar);

    // ── 下部：胴体（円錐台）。裾は少し絞り、下端に金縁を巻く ──
    const skirtH = domeY - 0.65;
    const skirtTopR = domeR;
    const skirtBotR = domeR * 0.92;
    const skirtGeo = new THREE.CylinderGeometry(skirtTopR, skirtBotR, skirtH, segments, 1, true);
    const skirtPos = skirtGeo.attributes.position;
    for (let i = 0; i < skirtPos.count; i++) {
        skirtPos.setZ(i, skirtPos.getZ(i) * 0.72);
    }
    skirtPos.needsUpdate = true;
    skirtGeo.computeVertexNormals();

    const skirt = new THREE.Mesh(skirtGeo, plateMat);
    skirt.name = 'breastplateSkirt';
    skirt.position.y = domeY - skirtH / 2;
    breastplateGroup.add(skirt);

    // 裾（腰まわり）の金縁トリム
    // 円環は回転前のローカルY軸が回転後のワールドZ軸になるため、
    // ワールドZ方向を0.72倍にするにはローカルscale.yを0.72にする
    const hemGeo = new THREE.TorusGeometry(skirtBotR, 0.035, 8, segments);
    const hem = new THREE.Mesh(hemGeo, trimMat);
    hem.name = 'breastplateHem';
    hem.rotation.x = Math.PI / 2;
    hem.scale.set(1, 0.72, 1);
    hem.position.y = domeY - skirtH;
    breastplateGroup.add(hem);

    // ── 胸の膨らみカバー：bustSize連動でchestの胸球体を甲冑色で覆う ──
    if (data.bustSize > 0) {
        const b  = data.bustSize;
        const p  = data.bustProtrude;
        const cr = (0.22 * b) * 1.08;

        let chestMesh = null;
        targetGroup.traverse(obj => {
            if (obj.isMesh && Math.abs(obj.position.y - 2.0) < 0.05
                && !obj.name.startsWith('shirt') && !obj.name.startsWith('breastplate')) {
                chestMesh = obj;
            }
        });

        if (chestMesh) {
            const bridgeGeo = new THREE.CylinderGeometry(cr, cr, 0.36, 20);
            bridgeGeo.rotateZ(Math.PI / 2);
            const bridge = new THREE.Mesh(bridgeGeo, plateMat);
            bridge.name = 'breastplateBridge';
            bridge.position.set(0, -0.05, p);
            chestMesh.add(bridge);

            const coverL = new THREE.Mesh(new THREE.SphereGeometry(cr, 16, 16), plateMat);
            coverL.name = 'breastplateCoverL';
            coverL.position.set(0.17, -0.05, p);
            chestMesh.add(coverL);

            const coverR = new THREE.Mesh(new THREE.SphereGeometry(cr, 16, 16), plateMat);
            coverR.name = 'breastplateCoverR';
            coverR.position.set(-0.17, -0.05, p);
            chestMesh.add(coverR);

            breastplateGroup.userData.bustCovers = [bridge, coverL, coverR];
        }
    }

    targetGroup.add(breastplateGroup);
    return breastplateGroup;
}

// ============================================================
// 軽装プレートアーマー：肩当て（左右）
// ============================================================
// 【設計方針】
//   ・shoulder関節(createArm内、characterGroup直下、y≈2.15)の子として追加し、
//     腕の回転・ポーズ変更に自動追従させる（袖と同じ考え方）
//   ・丸みのある小さなドーム＋縁取りリングのみのシンプルな構造（v1）
// ============================================================
function createShoulderArmor(data, targetGroup) {
    const plateColor = data.plateColor || '#d8dce0';
    const trimColor  = data.plateTrimColor || '#d4af37';
    const plateMat = new THREE.MeshLambertMaterial({ color: plateColor });
    const trimMat  = new THREE.MeshLambertMaterial({ color: trimColor });

    function buildPauldron() {
        const p = new THREE.Group();
        p.name = 'pauldron';

        // 肩関節を覆う丸いキャップ
        const capR = 0.30;
        const capThetaLen = Math.PI / 1.8;
        const capGeo = new THREE.SphereGeometry(capR, 16, 12, 0, Math.PI * 2, 0, capThetaLen);
        const cap = new THREE.Mesh(capGeo, plateMat);
        p.add(cap);

        // キャップ下端の金縁トリム
        const ringR = capR * Math.sin(capThetaLen);
        const ringY = capR * Math.cos(capThetaLen);
        const ring = new THREE.Mesh(new THREE.TorusGeometry(ringR, 0.03, 8, 24), trimMat);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = ringY;
        p.add(ring);

        return p;
    }

    // characterGroup直下のMeshを走査してshoulder(y≈2.15)を特定
    // ※createTShirt()のaddSleeve探索ロジックと同じ考え方
    targetGroup.children.forEach(child => {
        if (child.isMesh && Math.abs(child.position.y - 2.15) < 0.05) {
            const pauldron = buildPauldron();
            pauldron.position.set(0, 0.06, 0); // 関節球より少し上に載せる
            child.add(pauldron);
        }
    });
}

// ============================================================
// 下半身装備：ズボン（ヒップ部）
// ============================================================
// 太もも/膝/すね/裾は createLeg() 内でボーン直下に生成（既存構造を維持）。
// ここではヒップ（pelvis）を包む部分だけを担当する。
function createPants(color, targetGroup, pelvisMesh) {
    const pantsMat = new THREE.MeshLambertMaterial({ color: color });
    // pelvis（肌）を隠す
    pelvisMesh.visible = false;
    // pelvisを包むズボンヒップ
    const pPelvisGeo = new THREE.SphereGeometry(0.52, 20, 16);
    const pPelvis = new THREE.Mesh(pPelvisGeo, pantsMat);
    pPelvis.name = 'pantsPelvis';
    pPelvis.scale.set(1.20, 0.82, 0.76);
    pPelvis.position.y = 1.1;
    targetGroup.add(pPelvis);
    return pPelvis;
}

// ============================================================
// 下半身装備：スカート（腰・左右膝ボーン追従の動的版）
// ============================================================
// 【経緯】
// v1: 円錐台1本の静的パーツ → キック等で脚が貫通して見える
// v2: 左右の脚それぞれに独立した円柱(カプセル)を追従させる方式に変更
//     → 半径を裾に向けて広げた結果、左右のカプセルの円が
//       互いの中心を追い越して重なり、裾のあたりで断面同士が
//       ねじれて交差する見た目になってしまった（左右の円は
//       単純な2本の独立した円では、半径が脚の間隔の半分を超えた
//       瞬間に必ず交差する）。
// v3(今回): 左右の膝を「開口部の円」とみなし、その2つの円を
//     直線でつなぐ＝陸上トラックのような「スタジアム(カプセル)型」
//     の輪郭を1周分だけ作る。左右それぞれの半円＋それをつなぐ
//     直線の組み合わせなので、原理的に自己交差しない。
//     この輪郭を腰(1点)〜裾(スタジアム型)まで階層状にロフトして
//     1枚のメッシュにし、毎フレーム頂点座標だけを書き換える。
//     （腰では左右の中心が一致するため、スタジアム型は自然に
//       ただの円に縮退する）
//
// ※ characterGroup（キャラ全体のルート）は常に原点固定・無回転
//   （position/rotationを一切変更していない）という前提で、
//   取得したワールド座標をそのままcharacterGroup直下の子オブジェクトの
//   ローカル座標として使っている。将来キャラ全体を動かす／回転させる
//   実装を追加する場合は、targetGroup.worldToLocal()を通すこと。
//
// 再利用オブジェクト（フレーム毎の new Vector3 を避けるため
// モジュールスコープで1回だけ生成し使い回す）
const _dynSkirtTmp = {
    waistPos: new THREE.Vector3(),
    kneePos: [new THREE.Vector3(), new THREE.Vector3()],
    cL: new THREE.Vector3(), // その段(row)における左脚側の開口部中心
    cR: new THREE.Vector3(), // その段(row)における右脚側の開口部中心
};

function createDynamicSkirt(color, targetGroup, waistRef, legs) {
    const skirtMat = new THREE.MeshLambertMaterial({
        color: color,
        side: THREE.DoubleSide,
    });

    // ── 寸法 ──
    const waistR  = 0.58;  // 腰側の半径（1点に縮退した円）
    const hemR    = 0.80;  // 裾側の半径（左右の膝それぞれを囲む円）
    // 腰→膝の何%の位置で裾にするか。膝ボーンぴったりまで伸ばすと
    // 膝を丸ごと覆ってしまうため、手前で止めて元の膝を露出させる。
    const hemFrac = 0.80;
    const rows      = 6; // 腰(row0)〜裾(row rows-1)の輪切り段数
    const halfSegs  = 8; // 半円あたりの分割数（1周 = halfSegs*2）
    const segsPerRing = halfSegs * 2;

    const skirtGroup = new THREE.Group();
    skirtGroup.name = 'dynamicSkirtGroup';

    // ── 側面：腰〜裾をrows段の「スタジアム型リング」でロフトした1枚メッシュ ──
    const sidePositions = new Float32Array(rows * segsPerRing * 3);
    const sideGeo = new THREE.BufferGeometry();
    sideGeo.setAttribute('position', new THREE.BufferAttribute(sidePositions, 3));
    const sideIndices = [];
    for (let r = 0; r < rows - 1; r++) {
        for (let s = 0; s < segsPerRing; s++) {
            const s2 = (s + 1) % segsPerRing;
            const a = r * segsPerRing + s;
            const b = r * segsPerRing + s2;
            const c = (r + 1) * segsPerRing + s;
            const d = (r + 1) * segsPerRing + s2;
            sideIndices.push(a, c, b,  b, c, d);
        }
    }
    sideGeo.setIndex(sideIndices);
    const sideMesh = new THREE.Mesh(sideGeo, skirtMat);
    sideMesh.name = 'skirtSide';
    skirtGroup.add(sideMesh);

    // ★裾の蓋は付けない：閉じると床のような見た目になり不自然なため、
    //   スカートらしく裾は開けたまま（sideMeshのみ＝上下ともopenEnded）にする。

    targetGroup.add(skirtGroup);

    return {
        group: skirtGroup,
        waistRef,                                    // 腰の基準（pelvisメッシュ）
        kneeRefs: [legs[0].joint, legs[1].joint],     // 左膝・右膝（hip配下のknee Group）
        sideMesh,
        rows,
        segsPerRing,
        halfSegs,
        waistR,
        hemR,
        hemFrac,
    };
}

// createCharacter()のanimate()ループから毎フレーム呼び出す。
// 腰・左右膝の現在のワールド座標を取得し、各段(row)ごとに
// 「左右の開口部円をつないだスタジアム型」の頂点を計算し直す。
function updateDynamicSkirt(skirt) {
    if (!skirt) return;
    const t = _dynSkirtTmp;

    // 【重要】renderer.render()の直前に呼ぶだけだとmatrixWorldが
    // 前フレームの値のままなので、参照ボーンだけを明示的に更新する
    // （characterGroup全体をupdateMatrixWorld()するより軽い）。
    skirt.waistRef.updateWorldMatrix(true, false);
    t.waistPos.setFromMatrixPosition(skirt.waistRef.matrixWorld);
    for (let i = 0; i < 2; i++) {
        skirt.kneeRefs[i].updateWorldMatrix(true, false);
        t.kneePos[i].setFromMatrixPosition(skirt.kneeRefs[i].matrixWorld);
    }

    const sidePos = skirt.sideMesh.geometry.attributes.position;
    const segsPerRing = skirt.segsPerRing;
    const halfSegs = skirt.halfSegs;
    const angleStep = Math.PI / (halfSegs - 1); // 半円をhalfSegs点で「両端含めて」等分

    for (let r = 0; r < skirt.rows; r++) {
        const f = (r / (skirt.rows - 1)) * skirt.hemFrac; // 0(腰)〜hemFrac(裾)
        const radius = skirt.waistR + (skirt.hemR - skirt.waistR) * (r / (skirt.rows - 1));

        t.cL.lerpVectors(t.waistPos, t.kneePos[0], f); // 左脚側の開口部中心
        t.cR.lerpVectors(t.waistPos, t.kneePos[1], f); // 右脚側の開口部中心

        // 2つの中心を結ぶ方向(along)と、それに直交する方向(side)。
        // X-Z平面（水平面）内で計算する。腰(row0)では cL==cR になるため
        // 方向が定まらず、その場合はワールドX軸にフォールバックする
        // （その場合スタジアム型は自然にただの円へ縮退する）。
        let alongX = t.cR.x - t.cL.x, alongZ = t.cR.z - t.cL.z;
        let alen = Math.sqrt(alongX * alongX + alongZ * alongZ);
        if (alen < 1e-4) { alongX = 1; alongZ = 0; alen = 1; }
        alongX /= alen; alongZ /= alen;
        const sideX = -alongZ, sideZ = alongX; // 90度回転させた向き

        for (let s = 0; s < segsPerRing; s++) {
            const isRightArc = s < halfSegs; // 前半=右脚側の半円、後半=左脚側の半円
            const localAngle = isRightArc
                ? (-Math.PI / 2 + s * angleStep)
                : (Math.PI / 2 + (s - halfSegs) * angleStep);
            const cx = Math.cos(localAngle), sn = Math.sin(localAngle);
            const cenX = isRightArc ? t.cR.x : t.cL.x;
            const cenY = isRightArc ? t.cR.y : t.cL.y;
            const cenZ = isRightArc ? t.cR.z : t.cL.z;
            const px = cenX + radius * (cx * alongX + sn * sideX);
            const pz = cenZ + radius * (cx * alongZ + sn * sideZ);

            const idx = r * segsPerRing + s;
            sidePos.setXYZ(idx, px, cenY, pz);
        }
    }

    sidePos.needsUpdate = true;
    skirt.sideMesh.geometry.computeVertexNormals();
}

function disposeDynamicSkirt(skirt) {
    if (!skirt || !skirt.group) return;
    skirt.group.traverse((node) => {
        if (node.geometry) node.geometry.dispose();
        if (node.material) {
            const mats = Array.isArray(node.material) ? node.material : [node.material];
            mats.forEach((mat) => {
                if (mat.map) mat.map.dispose();
                mat.dispose();
            });
        }
    });
    if (skirt.group.parent) skirt.group.parent.remove(skirt.group);
}

// ============================================================
// 下半身装備：ロングスカートの裾延長パーツ
// ============================================================
// 【添付アイデアどおりの設計】
//   ・「スカート」本体（createDynamicSkirt／updateDynamicSkirt）は
//     一切変更しない。ロングスカートはその裾にこのパーツを
//     「継ぎ足す」ことで実現する。
//   ・足首の球中心から足先(つま先)までの長さを footLen とし、
//     footLen の2倍を半径とする球を左右の足首にそれぞれ置き、
//     その2球をつないだ「カプセル型」（スカート本体と同じ、
//     左右の円を直線でつなぐスタジアム型の輪郭を使うので
//     自己交差しない）を作る。
//   ・スカート本体の裾（開口部）とこのカプセル型を輪切りロフトで
//     つなぎ、カプセル型の方は足首の中心からfootLen分だけ下で
//     水平にカットして新たな開口部（＝ロングスカートの裾）とする。
//     球の断面公式 r(d) = √(R²−d²) （R=半径, d=球中心からの高さ）を使い、
//     カット面での開口部半径を求めている。
//
//   footLen の内訳（createLeg内のfoot/bareFootGroup形状より算出）：
//     ankle→foot オフセット      = (0, -0.10, +0.18)
//     foot→sole中心             = (0,  0,    +0.08)
//     sole半径0.20 × 奥行き倍率1.6 = 0.32（つま先方向への張り出し）
//     水平方向の合計 = 0.18+0.08+0.32 = 0.58 / 垂直オフセット = -0.10
//     footLen = √(0.58² + 0.10²) ≈ 0.59
const FOOT_LEN     = 0.59;
const CAPSULE_R     = FOOT_LEN * 2;                              // 「球を2倍」＝カプセル最大半径
const CAPSULE_CUT_DROP = FOOT_LEN;                                // 足首中心からこの分下でカット
const CAPSULE_CUT_R    = Math.sqrt(CAPSULE_R * CAPSULE_R - CAPSULE_CUT_DROP * CAPSULE_CUT_DROP); // カット面の開口部半径
const LONGSKIRT_T_PEAK = 0.6; // 全行の何%地点で最大膨らみ(CAPSULE_R)に達するか（0〜1）

function _longSkirtSmoothstep(x) {
    x = Math.max(0, Math.min(1, x));
    return x * x * (3 - 2 * x);
}

// 再利用オブジェクト（毎フレームnew Vector3しないため使い回す）
const _longSkirtTmp = {
    waistPos: new THREE.Vector3(),
    kneePos: [new THREE.Vector3(), new THREE.Vector3()],
    anklePos: [new THREE.Vector3(), new THREE.Vector3()],
    hemC: [new THREE.Vector3(), new THREE.Vector3()],  // スカート本体の裾（継ぎ目）中心
    cutC: [new THREE.Vector3(), new THREE.Vector3()],  // カット面（新しい開口部）中心
    cL: new THREE.Vector3(),
    cR: new THREE.Vector3(),
};

// skirt: createDynamicSkirt()の戻り値（本体が無ければロングスカートも作らない）
// legs: animatedParts.legs（各要素に .ankle が必要）
function createLongSkirtExtension(color, targetGroup, skirt, legs) {
    if (!skirt) return null;

    const mat = new THREE.MeshLambertMaterial({
        color: color,
        side: THREE.DoubleSide,
    });

    const rows = 6; // 継ぎ目(row0)〜カット面(row rows-1)の輪切り段数
    // スカート本体と同じ分割数を使うことで、継ぎ目の頂点数がぴったり一致し
    // 隙間なくつながる。
    const segsPerRing = skirt.segsPerRing;
    const halfSegs     = skirt.halfSegs;

    const group = new THREE.Group();
    group.name = 'longSkirtExtGroup';

    const positions = new Float32Array(rows * segsPerRing * 3);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const indices = [];
    for (let r = 0; r < rows - 1; r++) {
        for (let s = 0; s < segsPerRing; s++) {
            const s2 = (s + 1) % segsPerRing;
            const a = r * segsPerRing + s;
            const b = r * segsPerRing + s2;
            const c = (r + 1) * segsPerRing + s;
            const d = (r + 1) * segsPerRing + s2;
            indices.push(a, c, b,  b, c, d);
        }
    }
    geo.setIndex(indices);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'longSkirtSide';
    group.add(mesh);

    // ★裾（カット面）の蓋も付けない：スカート本体と同じく開けたままにする。
    targetGroup.add(group);

    return {
        group,
        mesh,
        waistRef: skirt.waistRef,                              // 腰の基準（スカート本体と共有）
        kneeRefs: skirt.kneeRefs,                               // 左右膝（スカート本体と共有）
        ankleRefs: [legs[0].ankle, legs[1].ankle],              // 左右足首
        rows, segsPerRing, halfSegs,
        hemR: skirt.hemR, hemFrac: skirt.hemFrac,               // スカート本体の裾と完全一致させる継ぎ目情報
    };
}

// createCharacter()のanimate()ループから毎フレーム呼び出す。
// スカート本体の裾（継ぎ目）〜足首下のカット面までを輪切りロフトし直す。
function updateLongSkirtExtension(ext) {
    if (!ext) return;
    const t = _longSkirtTmp;

    ext.waistRef.updateWorldMatrix(true, false);
    t.waistPos.setFromMatrixPosition(ext.waistRef.matrixWorld);
    for (let i = 0; i < 2; i++) {
        ext.kneeRefs[i].updateWorldMatrix(true, false);
        t.kneePos[i].setFromMatrixPosition(ext.kneeRefs[i].matrixWorld);
        ext.ankleRefs[i].updateWorldMatrix(true, false);
        t.anklePos[i].setFromMatrixPosition(ext.ankleRefs[i].matrixWorld);

        // 継ぎ目＝スカート本体の裾中心（本体のupdateDynamicSkirtと同じ式）
        t.hemC[i].lerpVectors(t.waistPos, t.kneePos[i], ext.hemFrac);
        // カット面＝足首中心からfootLen分だけ真下
        t.cutC[i].copy(t.anklePos[i]);
        t.cutC[i].y -= CAPSULE_CUT_DROP;
    }

    const sidePos = ext.mesh.geometry.attributes.position;
    const segsPerRing = ext.segsPerRing;
    const halfSegs = ext.halfSegs;
    const angleStep = Math.PI / (halfSegs - 1);

    for (let r = 0; r < ext.rows; r++) {
        const rf = r / (ext.rows - 1); // 0(継ぎ目)〜1(カット面)

        // 半径：継ぎ目(hemR)→最大膨らみ(CAPSULE_R)→カット面(CAPSULE_CUT_R)
        // の2段階smoothstepで、球をfootLen分下でカットした形の裾広がりを作る。
        let radius;
        if (rf <= LONGSKIRT_T_PEAK) {
            radius = ext.hemR + (CAPSULE_R - ext.hemR) * _longSkirtSmoothstep(rf / LONGSKIRT_T_PEAK);
        } else {
            radius = CAPSULE_R + (CAPSULE_CUT_R - CAPSULE_R) * _longSkirtSmoothstep((rf - LONGSKIRT_T_PEAK) / (1 - LONGSKIRT_T_PEAK));
        }

        t.cL.lerpVectors(t.hemC[0], t.cutC[0], rf);
        t.cR.lerpVectors(t.hemC[1], t.cutC[1], rf);

        let alongX = t.cR.x - t.cL.x, alongZ = t.cR.z - t.cL.z;
        let alen = Math.sqrt(alongX * alongX + alongZ * alongZ);
        if (alen < 1e-4) { alongX = 1; alongZ = 0; alen = 1; }
        alongX /= alen; alongZ /= alen;
        const sideX = -alongZ, sideZ = alongX;

        for (let s = 0; s < segsPerRing; s++) {
            const isRightArc = s < halfSegs;
            const localAngle = isRightArc
                ? (-Math.PI / 2 + s * angleStep)
                : (Math.PI / 2 + (s - halfSegs) * angleStep);
            const cx = Math.cos(localAngle), sn = Math.sin(localAngle);
            const cenX = isRightArc ? t.cR.x : t.cL.x;
            const cenY = isRightArc ? t.cR.y : t.cL.y;
            const cenZ = isRightArc ? t.cR.z : t.cL.z;
            const px = cenX + radius * (cx * alongX + sn * sideX);
            const pz = cenZ + radius * (cx * alongZ + sn * sideZ);

            const idx = r * segsPerRing + s;
            sidePos.setXYZ(idx, px, cenY, pz);
        }
    }

    sidePos.needsUpdate = true;
    ext.mesh.geometry.computeVertexNormals();
}

function disposeLongSkirtExtension(ext) {
    if (!ext || !ext.group) return;
    ext.group.traverse((node) => {
        if (node.geometry) node.geometry.dispose();
        if (node.material) {
            const mats = Array.isArray(node.material) ? node.material : [node.material];
            mats.forEach((mat) => {
                if (mat.map) mat.map.dispose();
                mat.dispose();
            });
        }
    });
    if (ext.group.parent) ext.group.parent.remove(ext.group);
}

// ============================================================
// 初期キャラクター生成
// ============================================================
// ★ファイル分割の都合上、この呼び出しは元々 character-body.js 内の
//   createCharacter() 定義直後にあったが、createCharacter() が
//   createTShirt() 等（このファイルの関数）を呼び出すため、
//   それらの読み込み完了後であるこの位置に移動した。
createCharacter(characterData);
