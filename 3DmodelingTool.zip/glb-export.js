// ============================================================
// ポーズ → glTFアニメーションクリップ変換
// ============================================================
// 角度(rx=Pitch, ry=Yaw, rz=Roll)をglTFが扱える四元数配列[x,y,z,w]に変換。
// ポーズ編集パネルと同じ anglesToQuaternion（Yaw→Pitch→Rollの合成順）を使うことで、
// 画面上の見た目とGLBエクスポート結果が一致するようにしている。
function eulerToQuatArray(rx = 0, ry = 0, rz = 0) {
    const q = anglesToQuaternion(rx, ry, rz);
    return [q.x, q.y, q.z, q.w];
}

// ポーズで動かす11部品（頭 / 左右の肩・肘・手首 / 左右の股関節・膝）と
// POSESデータ内の対応する回転値を取得する
function getAnimatedJoints() {
    const p = animatedParts;
    return [
        { obj: p.head,          get: pose => pose.head },
        { obj: p.arms[0].root,  get: pose => pose.arms[0].root },
        { obj: p.arms[0].joint, get: pose => pose.arms[0].joint },
        { obj: p.arms[0].wrist, get: pose => pose.arms[0].wrist },
        { obj: p.arms[1].root,  get: pose => pose.arms[1].root },
        { obj: p.arms[1].joint, get: pose => pose.arms[1].joint },
        { obj: p.arms[1].wrist, get: pose => pose.arms[1].wrist },
        { obj: p.legs[0].root,  get: pose => pose.legs[0].root },
        { obj: p.legs[0].joint, get: pose => pose.legs[0].joint },
        { obj: p.legs[1].root,  get: pose => pose.legs[1].root },
        { obj: p.legs[1].joint, get: pose => pose.legs[1].joint },
    ];
}

// ============================================================
// ポーズごとの表情をGLBへ焼き込む仕組み
// ------------------------------------------------------------
// 【重大バグの原因（今回の修正対象）】
// 「表情OFFのポーズで表示するデフォルト顔」を、animatedParts.faceの
// eyesMesh/mouthMesh/eyebrowMeshという“今エディタ画面に表示中のメッシュ”を
// そのまま使い回して実装していた。ところがこれらのメッシュのmaterial.mapは
// applyFaceExpression()によってポーズ切替のたびに直接書き換えられる
// （＝「今表示中の表情」を保持しているだけで、キャラの「本来のデフォルト
// 表情」を表している保証が無い）。そのため、GLB出力の直前にどれかの
// ポーズ（表情ON）を表示・編集していると、その表情がそのまま「デフォルト
// 表情」としてGLB内の全OFFポーズに焼き込まれてしまうバグがあった。
//
// 【解決策】
// 「現在表示中の表情」と「GLBのデフォルト表情」を完全に分離する。
//   ・GLBのデフォルト表情専用メッシュは、characterDataではなく
//     DEFAULT_EXPRESSION定数（キャラタブの固定表情）から都度新規生成する。
//     animatedParts.faceの現在のメッシュ／テクスチャは一切参照しない。
//   ・ライブ表示用のeyesMesh/mouthMesh/eyebrowMeshは、エクスポートの間
//     scaleを0にして完全に除外し、GLBの内容に「今の画面状態」が
//     一切混ざらないようにする（出力後は元のscaleに戻す）。
//   ・表情を使うポーズごとにも、同様に独立した専用メッシュ（バリアント）を
//     都度新規生成する（CanvasTexture／Materialは一切共有しない）。
//   ・各ポーズのクリップは「そのポーズのバリアントだけscale=1で表示、
//     他は全部scale=0で非表示」というscaleトラックを持つ。
//     OFFのポーズは「デフォルト表情専用メッシュ」をscale=1にする。
// 出力が終わったら、この一時メッシュ群は破棄し、ライブ表示メッシュは
// 元のscaleに戻して、エディタ画面には一切影響を残さない。
// ============================================================

// GLB出力専用の「デフォルト表情」メッシュ＋表情ONポーズごとの専用メッシュ（バリアント）を生成する。
// ★必須ルール：
//   ・デフォルト表情は必ずDEFAULT_EXPRESSION（characterDataではなく、
//     キャラタブの固定表情定数）から生成する。animatedParts.faceの
//     現在のメッシュ／テクスチャ／マテリアルは絶対に参照・流用しない。
//   ・各スロットのexpressionから毎回ディープコピー＋新規CanvasTextureを
//     作るため、スロット間・デフォルト・エディタ表示中の現在の顔との間で
//     オブジェクト参照が一切重複しない。
function buildExpressionVariantsForExport() {
    const face = animatedParts.face;
    if (!face) return null;
    const headObj = face.eyesMesh.parent; // headメッシュ
    const variants = [];      // { slotIndex, eyes, mouth, eyebrow }（Meshオブジェクト）
    const disposables = [];   // 出力後に破棄するMaterial/Texture

    // ── ライブ表示メッシュ（今画面に表示中の表情）は、GLBの内容から完全に除外する ──
    // 出力後に元へ戻せるよう、現在のscaleを退避してから0にする
    const liveScales = {
        eyes:    face.eyesMesh.scale.clone(),
        mouth:   face.mouthMesh.scale.clone(),
        eyebrow: face.eyebrowMesh.scale.clone(),
    };
    face.eyesMesh.scale.set(0, 0, 0);
    face.mouthMesh.scale.set(0, 0, 0);
    face.eyebrowMesh.scale.set(0, 0, 0);

    // ── 「本来のデフォルト表情」を、DEFAULT_EXPRESSION定数から独立生成する ──
    // ★禁止パターン：`face.eyesMesh` や `face.eyesMesh.material.map` を
    //   デフォルト表情として使い回すこと。ここでは絶対にそれをしない。
    const defaultEyesMat = new THREE.MeshBasicMaterial({ map: createEyeTexture(DEFAULT_EXPRESSION.eyeType, characterData.eyeColor), transparent: true });
    const defaultEyesMesh = new THREE.Mesh(face.eyesMesh.geometry, defaultEyesMat); // ジオメトリ（形状）のみ共有。テクスチャ/マテリアルは独立
    defaultEyesMesh.position.copy(face.eyesMesh.position);
    headObj.add(defaultEyesMesh);

    const defaultMouthMat = new THREE.MeshBasicMaterial({ map: createMouthTexture(DEFAULT_EXPRESSION.mouthType), transparent: true });
    const defaultMouthMesh = new THREE.Mesh(face.mouthMesh.geometry, defaultMouthMat);
    defaultMouthMesh.position.copy(face.mouthMesh.position);
    headObj.add(defaultMouthMesh);

    const defaultBrowMat = new THREE.MeshBasicMaterial({ map: createEyebrowTexture(DEFAULT_EXPRESSION.eyebrowType), transparent: true });
    const defaultBrowMesh = new THREE.Mesh(face.eyebrowMesh.geometry, defaultBrowMat);
    defaultBrowMesh.position.copy(face.eyebrowMesh.position);
    headObj.add(defaultBrowMesh);

    disposables.push(defaultEyesMat, defaultEyesMat.map, defaultMouthMat, defaultMouthMat.map, defaultBrowMat, defaultBrowMat.map);

    // ── 表情を使うポーズごとに、専用メッシュ（バリアント）を生成する ──
    mySlots.forEach((slot, i) => {
        if (!slot.expressionEnabled) return;
        const expr = cloneExpression(slot.expression);

        const eyesMat = new THREE.MeshBasicMaterial({ map: createEyeTexture(expr.eyeType, characterData.eyeColor), transparent: true });
        const eyesMesh = new THREE.Mesh(face.eyesMesh.geometry, eyesMat); // ジオメトリは元メッシュと共有（形状は同一のため）
        eyesMesh.position.copy(face.eyesMesh.position);
        eyesMesh.scale.set(0, 0, 0); // 既定は非表示。該当ポーズのクリップだけがscale=1にする
        headObj.add(eyesMesh);

        const mouthMat = new THREE.MeshBasicMaterial({ map: createMouthTexture(expr.mouthType), transparent: true });
        const mouthMesh = new THREE.Mesh(face.mouthMesh.geometry, mouthMat);
        mouthMesh.position.copy(face.mouthMesh.position);
        mouthMesh.scale.set(0, 0, 0);
        headObj.add(mouthMesh);

        const browMat = new THREE.MeshBasicMaterial({ map: createEyebrowTexture(expr.eyebrowType), transparent: true });
        const browMesh = new THREE.Mesh(face.eyebrowMesh.geometry, browMat);
        browMesh.position.copy(face.eyebrowMesh.position);
        browMesh.scale.set(0, 0, 0);
        headObj.add(browMesh);

        variants.push({ slotIndex: i, eyes: eyesMesh, mouth: mouthMesh, eyebrow: browMesh });
        disposables.push(eyesMat, eyesMat.map, mouthMat, mouthMat.map, browMat, browMat.map);
    });

    return {
        headObj,
        variants,
        disposables,
        // OFFのポーズが可視トグルの対象にする「本来のデフォルト表情」専用メッシュ
        defaultFace: { eyes: defaultEyesMesh, mouth: defaultMouthMesh, eyebrow: defaultBrowMesh },
        // 出力後に元のscaleへ復元するための情報（ライブ表示メッシュ自体は変更・破棄しない）
        liveFace: { eyesMesh: face.eyesMesh, mouthMesh: face.mouthMesh, eyebrowMesh: face.eyebrowMesh },
        liveScales,
    };
}

// エクスポート用に生成した一時メッシュ群をシーンから取り除き、GPUメモリを解放する。
// ライブ表示メッシュ（エディタ画面用）は破棄せず、退避しておいたscaleに戻すだけにする。
function removeExpressionVariants(ctx) {
    if (!ctx) return;
    ctx.liveFace.eyesMesh.scale.copy(ctx.liveScales.eyes);
    ctx.liveFace.mouthMesh.scale.copy(ctx.liveScales.mouth);
    ctx.liveFace.eyebrowMesh.scale.copy(ctx.liveScales.eyebrow);

    ctx.headObj.remove(ctx.defaultFace.eyes, ctx.defaultFace.mouth, ctx.defaultFace.eyebrow);
    ctx.variants.forEach(v => {
        ctx.headObj.remove(v.eyes, v.mouth, v.eyebrow);
    });
    ctx.disposables.forEach(obj => { if (obj && obj.dispose) obj.dispose(); });
}

// obj.scaleを[0,duration]の2キーフレームで固定値に保持するトラックを作る（可視/非表示の切替に使用）
function buildFaceScaleTrack(obj, visible, duration) {
    const s = visible ? 1 : 0;
    return new THREE.VectorKeyframeTrack(
        `${obj.uuid}.scale`,
        [0, duration],
        [s, s, s, s, s, s]
    );
}

// 角度(rx,ry,rz)を、THREE.Object3Dのデフォルト回転順序('XYZ')でQuaternion配列[x,y,z,w]に変換。
// ★重要：剣(sword)は eulerToQuatArray / anglesToQuaternion のような 'YXZ' 順ではなく、
//   character-body.js / pose-data.js / pose-slots.js のいずれでも
//   `sword.rotation.set(x,y,z)` または `sword.rotation.x = ...` という
//   「.rotationへの直接代入」で回転が決まっている。この場合のEuler順序は
//   THREE.Object3Dのデフォルトである 'XYZ' になる。
//   剣のY軸回転(SWORD_BASE_ROTATION.y)が90°もあるため、'YXZ'で計算すると
//   ライブエディタの見た目と全く異なる方向になってしまう
//  （実機で「アプリとGLBで剣の向きが逆になる」不具合の原因はこれだった）。
//   そのためエクスポート時も、剣だけはこの専用ヘルパーで 'XYZ' 順に統一する。
const _swordWorkEuler = new THREE.Euler(0, 0, 0, 'XYZ');
const _swordWorkQuat   = new THREE.Quaternion();
function swordEulerToQuatArray(rx = 0, ry = 0, rz = 0) {
    _swordWorkEuler.set(rx, ry, rz, 'XYZ');
    _swordWorkQuat.setFromEuler(_swordWorkEuler);
    return [_swordWorkQuat.x, _swordWorkQuat.y, _swordWorkQuat.z, _swordWorkQuat.w];
}

// 1つのポーズを「保持」するクリップに変換（開始・終了とも同じ姿勢）
// slot/slotIndex/exprCtxは、このクリップに「そのポーズ専用の表情」の
// 可視トグルトラックを焼き込むために使う（省略時＝表情トラック無しの通常クリップ）
function buildPoseClip(pose, name, duration = 1.0, slot = null, slotIndex = -1, exprCtx = null) {
    const tracks = getAnimatedJoints().map(({ obj, get }) => {
        const r = get(pose) || {};
        const q = eulerToQuatArray(r.rx || 0, r.ry || 0, r.rz || 0);
        return new THREE.QuaternionKeyframeTrack(
            `${obj.uuid}.quaternion`,
            [0, duration],
            [...q, ...q]
        );
    });
    // 剣を持っている場合は、ベース回転＋ポーズごとのチルトをクリップに反映する
    // ★上記の理由により、腕・脚とは別のswordEulerToQuatArray（'XYZ'順）を使う
    if (animatedParts.sword) {
        const tilt = pose.swordTiltX ?? 0;
        const q = swordEulerToQuatArray(
            SWORD_BASE_ROTATION.x + tilt,
            SWORD_BASE_ROTATION.y,
            SWORD_BASE_ROTATION.z
        );
        tracks.push(new THREE.QuaternionKeyframeTrack(
            `${animatedParts.sword.uuid}.quaternion`,
            [0, duration],
            [...q, ...q]
        ));
    }

    // ── このポーズ専用の表情を可視トグルとして焼き込む ──
    // ★必須ルール：ここでは必ずslot（＝そのポーズ自身の保存データ）だけを見て
    //   判定する。「現在エディタに表示中の表情」は一切参照しない。
    // ★禁止パターン：animatedParts.face（ライブ表示メッシュ）をデフォルト表情
    //   として使わない。必ずexprCtx.defaultFace（DEFAULT_EXPRESSIONから
    //   独立生成したメッシュ）を使う。
    if (exprCtx && slot) {
        const d = exprCtx.defaultFace;
        const useDefaultFace = !slot.expressionEnabled; // OFFならデフォルト表情メッシュを表示
        tracks.push(buildFaceScaleTrack(d.eyes,    useDefaultFace, duration));
        tracks.push(buildFaceScaleTrack(d.mouth,   useDefaultFace, duration));
        tracks.push(buildFaceScaleTrack(d.eyebrow, useDefaultFace, duration));

        exprCtx.variants.forEach(v => {
            const visible = (v.slotIndex === slotIndex); // 自分のポーズのバリアントだけ表示
            tracks.push(buildFaceScaleTrack(v.eyes,    visible, duration));
            tracks.push(buildFaceScaleTrack(v.mouth,   visible, duration));
            tracks.push(buildFaceScaleTrack(v.eyebrow, visible, duration));
        });
    }

    return new THREE.AnimationClip(name, duration, tracks);
}

// 自分のプリセット（mySlots＝編集・自動保存された最新の内容）をクリップ化
// （GLBに埋め込み、Blender等のアニメ一覧から名前を選んで姿勢を切り替えられるようにする）
// ※以前はここで固定値の POSES を参照していたため、ポーズ編集パネルで
//   調整した内容がGLBに反映されないバグがあった。mySlots を見るように修正。
function buildPoseClips(exprCtx) {
    // ── デバッグ：GLB出力直前に、デフォルト表情と各ポーズの表情設定が
    //    独立した値を保持しているかをコンソールに表示して確認できるようにする ──
    console.log('=== GLB Export Expression ===');
    console.log(`Default : eye=${DEFAULT_EXPRESSION.eyeType}, mouth=${DEFAULT_EXPRESSION.mouthType}, brow=${DEFAULT_EXPRESSION.eyebrowType}`);
    mySlots.forEach((slot, i) => {
        const e = slot.expressionEnabled ? slot.expression : DEFAULT_EXPRESSION;
        console.log(`Pose${i + 1}[${slot.name}] : ON=${slot.expressionEnabled}, eye=${e.eyeType}, mouth=${e.mouthType}, brow=${e.eyebrowType}`);
    });

    return mySlots.map((slot, i) => {
        // ラベルの絵文字部分を除いた名前をクリップ名にする（例:「😊 待機」→「待機」）
        const clipName = slot.name.split(' ').slice(1).join(' ') || slot.name;
        return buildPoseClip(slot.poseSnapshot, clipName, 1.0, slot, i, exprCtx);
    });
}

// 5. ダウンロード
document.getElementById('downloadBtn').addEventListener('click', () => {
    const exporter = new THREE.GLTFExporter();
    // 表情を使うポーズごとに専用メッシュを一時生成してから、それを踏まえてクリップを作る
    const exprCtx = buildExpressionVariantsForExport();
    const animations = buildPoseClips(exprCtx);

    // 【重要】metalness:0/roughness:1のMeshStandardMaterialに変換しても、
    // ビューワによっては曲面のフレネル反射でうっすら「テカり」が残ることがある。
    // これを確実に無くすため、目・口と同じ「アンリット(ライティング計算なし)」の
    // MeshBasicMaterialに変換してエクスポートする。反射計算そのものが
    // 行われなくなるため、どのビューワでも金属的な照り返しは発生しない。
    // （編集画面のような陰影は無くなり、全体がベタ塗りの質感になる）
    const savedMaterials = [];
    characterGroup.traverse(obj => {
        if (!obj.isMesh || !obj.material) return;
        const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        const replaced = mats.map(m => {
            if (m.isMeshBasicMaterial) return m;
            return new THREE.MeshBasicMaterial({
                color: m.color ? m.color.clone() : 0xffffff,
                map: m.map || null,
                transparent: !!m.transparent,
                opacity: m.opacity !== undefined ? m.opacity : 1,
                alphaTest: m.alphaTest || 0,
                side: m.side
            });
        });
        savedMaterials.push({ obj, material: obj.material });
        obj.material = Array.isArray(obj.material) ? replaced : replaced[0];
    });

    exporter.parse(characterGroup, function (result) {
        // マテリアルを元に戻す（編集画面の見た目には影響させない）
        savedMaterials.forEach(({ obj, material }) => { obj.material = material; });
        // 表情バリアント用の一時メッシュ／マテリアル／テクスチャを破棄する
        // （エディタ画面には一切残さない）
        removeExpressionVariants(exprCtx);

        const blob = new Blob([result], { type: 'application/octet-stream' });
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = URL.createObjectURL(blob);
        link.download = 'my_character.glb';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
    }, { binary: true, animations: animations });
});
