// 1. 初期設定
const container = document.getElementById('canvas-container');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 3, 10);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
container.appendChild(renderer.domElement);

const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; 
controls.target.set(0, 2, 0);

scene.add(new THREE.AmbientLight(0xffffff, 0.6));
const dirLight = new THREE.DirectionalLight(0xffffff, 0.6);
dirLight.position.set(5, 10, 7);
scene.add(dirLight);

// 2. テクスチャ生成
// ── 目テクスチャ：トモコレ風に12種類対応 ──────────────────────
// 左目 cx=64（外側=画面左方向）／右目 cx=192（外側=画面右方向）
function createEyeTexture(type, eyeColor) {
    eyeColor = eyeColor || '#000000';
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 256, 128);

    // fn(cx, outerDir) を左右の目に対して呼ぶ。outerDir は「外側方向」の符号
    // （左目=-1・右目=+1）。offset * outerDir で常に「外側へ動く量」になる。
    function eachEye(fn) {
        fn(64, -1);
        fn(192, 1);
    }

    switch (type) {
        case 'anime01': // 標準丸目
            eachEye((cx) => {
                ctx.fillStyle = eyeColor;
                ctx.beginPath(); ctx.ellipse(cx, 64, 20, 35, 0, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#fff';
                ctx.beginPath(); ctx.arc(cx, 45, 8, 0, Math.PI * 2); ctx.fill();
            });
            break;

        case 'anime02': // ジト目（横長・フラット）
            eachEye((cx) => {
                ctx.fillStyle = eyeColor;
                ctx.fillRect(cx - 24, 44, 48, 16);
            });
            break;

        case 'anime03': // 笑顔（にっこり弧線・目を閉じた笑み）
            eachEye((cx) => {
                ctx.lineWidth = 8; ctx.strokeStyle = '#000'; ctx.lineCap = 'round';
                ctx.beginPath(); ctx.arc(cx, 70, 24, Math.PI, Math.PI * 2); ctx.stroke();
            });
            break;

        case 'anime04': // つり目（外側の吊り上がった鋭い目）
            eachEye((cx, o) => {
                ctx.fillStyle = eyeColor;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * o, 66);
                ctx.quadraticCurveTo(cx, 34, cx + 24 * o, 46);
                ctx.quadraticCurveTo(cx + 6 * o, 76, cx - 26 * o, 66);
                ctx.closePath(); ctx.fill();
            });
            break;

        case 'anime05': // 泣き目（涙をたたえた丸目）
            eachEye((cx, o) => {
                ctx.fillStyle = eyeColor;
                ctx.beginPath(); ctx.ellipse(cx, 62, 18, 28, 0, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#fff';
                ctx.beginPath(); ctx.arc(cx, 50, 7, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#7ec8ff';
                ctx.beginPath();
                ctx.moveTo(cx + 20 * o, 88);
                ctx.quadraticCurveTo(cx + 28 * o, 104, cx + 20 * o, 114);
                ctx.quadraticCurveTo(cx + 12 * o, 104, cx + 20 * o, 88);
                ctx.fill();
            });
            break;

        case 'anime06': // 驚き（大きく見開いた目）
            eachEye((cx) => {
                ctx.fillStyle = '#fff';
                ctx.beginPath(); ctx.arc(cx, 62, 32, 0, Math.PI * 2); ctx.fill();
                ctx.lineWidth = 5; ctx.strokeStyle = '#000';
                ctx.beginPath(); ctx.arc(cx, 62, 32, 0, Math.PI * 2); ctx.stroke();
                ctx.fillStyle = eyeColor;
                ctx.beginPath(); ctx.arc(cx, 64, 15, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#fff';
                ctx.beginPath(); ctx.arc(cx, 56, 5, 0, Math.PI * 2); ctx.fill();
            });
            break;

        case 'anime07': // ハート目
            eachEye((cx) => {
                ctx.fillStyle = '#ff5c8a';
                ctx.beginPath();
                ctx.moveTo(cx, 88);
                ctx.bezierCurveTo(cx - 34, 55, cx - 18, 30, cx, 46);
                ctx.bezierCurveTo(cx + 18, 30, cx + 34, 55, cx, 88);
                ctx.fill();
            });
            break;

        case 'anime08': // キラキラ（星の光＋丸目）
            eachEye((cx) => {
                ctx.fillStyle = eyeColor;
                ctx.beginPath(); ctx.ellipse(cx, 64, 20, 34, 0, 0, Math.PI * 2); ctx.fill();
                function star(sx, sy, r) {
                    ctx.fillStyle = '#fff';
                    ctx.beginPath();
                    for (let i = 0; i < 5; i++) {
                        const a = -Math.PI / 2 + i * (Math.PI * 2 / 5);
                        const a2 = a + Math.PI / 5;
                        ctx.lineTo(sx + Math.cos(a) * r, sy + Math.sin(a) * r);
                        ctx.lineTo(sx + Math.cos(a2) * r * 0.45, sy + Math.sin(a2) * r * 0.45);
                    }
                    ctx.closePath(); ctx.fill();
                }
                star(cx - 6, 48, 11);
                star(cx + 9, 76, 6);
            });
            break;

        case 'anime09': // 半目（けだるげ・眠たそうな半開き目）
            eachEye((cx) => {
                ctx.fillStyle = eyeColor;
                ctx.beginPath();
                ctx.moveTo(cx - 26, 60);
                ctx.quadraticCurveTo(cx, 46, cx + 26, 60);
                ctx.quadraticCurveTo(cx, 78, cx - 26, 60);
                ctx.fill();
                // 上瞼側を消して半開きに見せる
                ctx.globalCompositeOperation = 'destination-out';
                ctx.fillRect(cx - 30, 30, 60, 22);
                ctx.globalCompositeOperation = 'source-over';
            });
            break;

        case 'anime10': // にこ目（浅く優しい弧・anime03より控えめ）
            eachEye((cx) => {
                ctx.lineWidth = 7; ctx.strokeStyle = '#000'; ctx.lineCap = 'round';
                ctx.beginPath(); ctx.arc(cx, 84, 20, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
            });
            break;

        case 'anime11': // ウインク（片目だけ閉じる）
            ctx.fillStyle = eyeColor;
            ctx.beginPath(); ctx.ellipse(64, 64, 20, 35, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.beginPath(); ctx.arc(64, 45, 8, 0, Math.PI * 2); ctx.fill();
            ctx.lineWidth = 8; ctx.strokeStyle = '#000'; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.arc(192, 70, 24, Math.PI, Math.PI * 2); ctx.stroke();
            break;

        case 'anime12': // ぐるぐる（渦巻き目）
            eachEye((cx) => {
                ctx.strokeStyle = eyeColor; ctx.lineWidth = 4; ctx.lineCap = 'round';
                ctx.beginPath();
                const turns = 2.2;
                for (let a = 0; a <= turns * Math.PI * 2; a += 0.15) {
                    const r = 2 + a * 3.2;
                    const x = cx + Math.cos(a) * r;
                    const y = 64 + Math.sin(a) * r;
                    if (a === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                }
                ctx.stroke();
            });
            break;

        default:
            eachEye((cx) => {
                ctx.fillStyle = eyeColor;
                ctx.beginPath(); ctx.ellipse(cx, 64, 20, 35, 0, 0, Math.PI * 2); ctx.fill();
            });
    }

    return new THREE.CanvasTexture(canvas);
}

// ── 口テクスチャ：12種類対応 ──────────────────────────────
function createMouthTexture(type) {
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 128, 64);
    ctx.strokeStyle = '#000'; ctx.fillStyle = '#000'; ctx.lineCap = 'round';

    switch (type) {
        case 'mouth01': // 普通
            ctx.lineWidth = 5;
            ctx.beginPath(); ctx.moveTo(40, 18); ctx.quadraticCurveTo(64, 24, 88, 18); ctx.stroke();
            break;

        case 'mouth02': // 笑顔
            ctx.lineWidth = 6;
            ctx.beginPath(); ctx.arc(64, 6, 20, 0, Math.PI); ctx.stroke();
            break;

        case 'mouth03': // 大笑い
            ctx.beginPath(); ctx.ellipse(64, 20, 26, 18, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.beginPath(); ctx.ellipse(64, 9, 24, 8, 0, 0, Math.PI); ctx.fill();
            break;

        case 'mouth04': // O口
            ctx.beginPath(); ctx.ellipse(64, 16, 13, 16, 0, 0, Math.PI * 2); ctx.fill();
            break;

        case 'mouth05': // 真一文字
            ctx.lineWidth = 6;
            ctx.beginPath(); ctx.moveTo(38, 14); ctx.lineTo(90, 14); ctx.stroke();
            break;

        case 'mouth06': // への字
            ctx.lineWidth = 6;
            ctx.beginPath();
            ctx.moveTo(38, 10); ctx.lineTo(64, 22); ctx.lineTo(90, 6);
            ctx.stroke();
            break;

        case 'mouth07': // 泣き口（波打つ口）
            ctx.lineWidth = 5;
            ctx.beginPath();
            ctx.moveTo(36, 12);
            ctx.quadraticCurveTo(46, 26, 56, 14);
            ctx.quadraticCurveTo(64, 26, 72, 14);
            ctx.quadraticCurveTo(82, 26, 92, 12);
            ctx.stroke();
            break;

        case 'mouth08': // ニヤリ（片側が上がる不敵な笑み）
            ctx.lineWidth = 6;
            ctx.beginPath();
            ctx.moveTo(40, 16); ctx.quadraticCurveTo(66, 24, 92, 4);
            ctx.stroke();
            break;

        case 'mouth09': // あくび（縦に大きく開いた口）
            ctx.beginPath(); ctx.ellipse(64, 20, 15, 24, 0, 0, Math.PI * 2); ctx.fill();
            break;

        case 'mouth10': // ベー（舌を出す）
            ctx.beginPath(); ctx.ellipse(64, 15, 20, 15, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ff8fa3';
            ctx.beginPath(); ctx.ellipse(64, 30, 9, 14, 0, 0, Math.PI * 2); ctx.fill();
            break;

        case 'mouth11': // 歯見せ（歯の見える笑顔）
            ctx.beginPath(); ctx.arc(64, 4, 22, 0, Math.PI); ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.fillRect(44, 4, 40, 9);
            break;

        case 'mouth12': // 満面の笑み（大きく開いた歯見せ笑顔）
            ctx.beginPath(); ctx.ellipse(64, 12, 30, 20, 0, 0, Math.PI); ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.fillRect(38, 10, 52, 11);
            break;

        default:
            ctx.lineWidth = 6;
            ctx.beginPath(); ctx.arc(64, 10, 20, 0, Math.PI); ctx.stroke();
    }

    return new THREE.CanvasTexture(canvas);
}

// ── 眉テクスチャ：10種類対応 ──────────────────────────────
// 左眉 cx=64／右眉 cx=192。side=+1(左眉)/-1(右眉)。
// outerX = cx - 26*side（外側）／innerX = cx + 26*side（内側・鼻寄り）
function createEyebrowTexture(type) {
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 100;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 256, 100);
    ctx.strokeStyle = '#2a2016'; ctx.fillStyle = '#2a2016'; ctx.lineCap = 'round';

    function eachBrow(fn) {
        fn(64, 1);   // 左眉
        fn(192, -1); // 右眉
    }

    switch (type) {
        case 'brow01': // 普通
            eachBrow((cx, side) => {
                ctx.lineWidth = 8;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 55);
                ctx.quadraticCurveTo(cx, 45, cx + 26 * side, 52);
                ctx.stroke();
            });
            break;

        case 'brow02': // 太眉
            eachBrow((cx, side) => {
                ctx.lineWidth = 16;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 55);
                ctx.quadraticCurveTo(cx, 44, cx + 26 * side, 52);
                ctx.stroke();
            });
            break;

        case 'brow03': // 細眉
            eachBrow((cx, side) => {
                ctx.lineWidth = 4;
                ctx.beginPath();
                ctx.moveTo(cx - 24 * side, 54);
                ctx.quadraticCurveTo(cx, 46, cx + 24 * side, 51);
                ctx.stroke();
            });
            break;

        case 'brow04': // 怒り（外側が上がり内側が下がる・つり眉）
            eachBrow((cx, side) => {
                ctx.lineWidth = 10;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 36);
                ctx.lineTo(cx + 26 * side, 62);
                ctx.stroke();
            });
            break;

        case 'brow05': // 困り（内側が上がる・優しい八の字）
            eachBrow((cx, side) => {
                ctx.lineWidth = 8;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 58);
                ctx.quadraticCurveTo(cx, 42, cx + 26 * side, 40);
                ctx.stroke();
            });
            break;

        case 'brow06': // ハの字（困り眉をより直線的・極端に）
            eachBrow((cx, side) => {
                ctx.lineWidth = 9;
                ctx.beginPath();
                ctx.moveTo(cx - 24 * side, 66);
                ctx.lineTo(cx + 24 * side, 36);
                ctx.stroke();
            });
            break;

        case 'brow07': // 上がり眉（外側が上がるキリッとした眉）
            eachBrow((cx, side) => {
                ctx.lineWidth = 8;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 34);
                ctx.quadraticCurveTo(cx, 44, cx + 26 * side, 56);
                ctx.stroke();
            });
            break;

        case 'brow08': // 下がり眉（外側が下がる優しい眉）
            eachBrow((cx, side) => {
                ctx.lineWidth = 8;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 62);
                ctx.quadraticCurveTo(cx, 48, cx + 26 * side, 42);
                ctx.stroke();
            });
            break;

        case 'brow09': // 驚き（高い位置でアーチ状に上がる）
            eachBrow((cx, side) => {
                ctx.lineWidth = 7;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 42);
                ctx.quadraticCurveTo(cx, 12, cx + 26 * side, 42);
                ctx.stroke();
            });
            break;

        case 'brow10': // 無し
            break;

        default:
            eachBrow((cx, side) => {
                ctx.lineWidth = 8;
                ctx.beginPath();
                ctx.moveTo(cx - 26 * side, 55);
                ctx.quadraticCurveTo(cx, 45, cx + 26 * side, 52);
                ctx.stroke();
            });
    }

    return new THREE.CanvasTexture(canvas);
}

// 3. キャラクター生成
let characterGroup = null;
let animatedParts = {};
// ★ 修正：初期データに earType: "human" を追加
// ★表情システム改修：eyeType/mouthType/eyebrowTypeはキャラ固有の値ではなくなり
//   「デフォルト表情」（DEFAULT_EXPRESSION、下記）として一本化されたため、
//   characterDataからは削除した。eyeColor（色）だけは表情に依存しないキャラ属性
//   として引き続きここで保持する。
let characterData = { headScaleY: 1.1, headScaleX: 1.0, jawWidth: 0.8, eyeColor: "#000000", hairType: "short01", hairColor: "#333333", bodyColor: "#ffe0c0", bustSize: 0.5, earType: "human", bustProtrude: 0.33, shirtColor: "#ffffff", topWear: "shirt", bottomWear: "none", pantsColor: "#4466aa", skirtColor: "#ffffff", bootsColor: "none", swordType: "none", hasShield: false, hasHelmet: false, plateColor: "#d8dce0", plateTrimColor: "#d4af37" };

// ============================================================
// 表情システム（ポーズごとの目・眉・口）
// ------------------------------------------------------------
// 設計:
//   ・キャラタブの表情は「デフォルト表情」に固定（DEFAULT_EXPRESSION）
//   ・ポーズごとに「表情を使用する」ON/OFF＋表情プリセットを保存できる
//   ・OFFの時はDEFAULT_EXPRESSIONを表示、ONの時はそのポーズ専用の表情を表示
// ============================================================

// デフォルト表情（キャラタブ＝目:標準丸目／口:普通／眉:普通、固定値）
const DEFAULT_EXPRESSION = { eyeType: 'anime01', mouthType: 'mouth01', eyebrowType: 'brow01' };

// ポーズに割り当てられる8種の表情プリセット
const EXPRESSION_PRESETS = [
    { key: 'normal',     emoji: '😊', label: '普通',           usage: '待機・歩き',         eyeType: 'anime01', mouthType: 'mouth01', eyebrowType: 'brow01' },
    { key: 'smile',      emoji: '😄', label: '笑顔',           usage: '会話・勝利',         eyeType: 'anime01', mouthType: 'mouth11', eyebrowType: 'brow01' },
    { key: 'angry',      emoji: '😠', label: '怒り',           usage: '攻撃・必殺技',       eyeType: 'anime04', mouthType: 'mouth06', eyebrowType: 'brow04' },
    { key: 'surprised',  emoji: '😲', label: '驚き',           usage: 'ダメージ・イベント', eyeType: 'anime06', mouthType: 'mouth04', eyebrowType: 'brow09' },
    { key: 'pain',       emoji: '😣', label: '痛い',           usage: '被弾・吹き飛び',     eyeType: 'anime09', mouthType: 'mouth07', eyebrowType: 'brow06' },
    { key: 'cry',        emoji: '😢', label: '泣き',           usage: '戦闘不能・イベント', eyeType: 'anime05', mouthType: 'mouth07', eyebrowType: 'brow05' },
    { key: 'serious',    emoji: '😤', label: '真剣',           usage: 'ボス戦・構え',       eyeType: 'anime04', mouthType: 'mouth05', eyebrowType: 'brow07' },
    { key: 'joy',        emoji: '😆', label: '目を閉じた笑顔', usage: '喜び・クリア',       eyeType: 'anime03', mouthType: 'mouth12', eyebrowType: 'brow01' },
];

// {eyeType, mouthType, eyebrowType} のディープコピーを作る。
// ★必須ルール：ポーズ間・プリセット間で同じオブジェクト参照を共有しないため、
//   表情を保存・適用するあらゆる箇所は必ずこの関数を経由する。
function cloneExpression(expr) {
    const e = expr || DEFAULT_EXPRESSION;
    return { eyeType: e.eyeType, mouthType: e.mouthType, eyebrowType: e.eyebrowType };
}

// 現在エディタに表示中の表情（キャラ再構築後の再適用に使う。下のapplyFaceExpressionが更新する）
let currentDisplayedExpression = cloneExpression(DEFAULT_EXPRESSION);

// 目・口・眉のCanvasTexture/Materialを、指定した表情の内容に直接差し替える。
// ★重要：createCharacter()でキャラ全体を再構築するのではなく、既存メッシュの
//   material.mapだけを差し替えるので、ポーズ切替のたびに毎回キャラを
//   再構築する重い処理を避けられる。
// ★古いCanvasTextureは必ずdispose()し、GPUメモリリークを防ぐ。
function applyFaceExpression(expr) {
    const e = cloneExpression(expr);
    currentDisplayedExpression = e;
    const face = animatedParts && animatedParts.face;
    if (!face) return;

    const newEyeTex = createEyeTexture(e.eyeType, characterData.eyeColor);
    const oldEyeTex = face.eyes.map;
    face.eyes.map = newEyeTex;
    face.eyes.needsUpdate = true;
    if (oldEyeTex) oldEyeTex.dispose();

    const newMouthTex = createMouthTexture(e.mouthType);
    const oldMouthTex = face.mouth.map;
    face.mouth.map = newMouthTex;
    face.mouth.needsUpdate = true;
    if (oldMouthTex) oldMouthTex.dispose();

    const newBrowTex = createEyebrowTexture(e.eyebrowType);
    const oldBrowTex = face.eyebrow.map;
    face.eyebrow.map = newBrowTex;
    face.eyebrow.needsUpdate = true;
    if (oldBrowTex) oldBrowTex.dispose();
}
window.applyFaceExpression = applyFaceExpression;

// スロットの状態から「今表示すべき表情」を導く（OFF or 未設定ならデフォルト表情）
function getEffectiveExpression(slot) {
    if (slot && slot.expressionEnabled && slot.expression) return slot.expression;
    return DEFAULT_EXPRESSION;
}
window.getEffectiveExpression = getEffectiveExpression;

// createCharacter()でface周りのメッシュ/マテリアルが新しいオブジェクトに
// 置き換わった直後に呼ばれ、直前まで表示していた表情を新しいメッシュに
// 再適用する。これが無いと、髪色変更など無関係な操作でキャラを再構築する
// たびに表情がデフォルトへ戻ってしまう。
window._reapplyCurrentExpression = function () {
    applyFaceExpression(currentDisplayedExpression);
};

// 剣の基本姿勢（右手で握った状態。切っ先は正面・縦持ち）
// ポーズごとの swordTiltX はこのX値に加算される追加の上下チルト
const SWORD_BASE_ROTATION = { x: Math.PI / 2, y: Math.PI / 2, z: 0.1 };

// ── メモリ解放ヘルパー ──────────────────────────────
// characterGroup を作り直す前に、古いGroup配下の
// ジオメトリ・マテリアル・テクスチャ（目/口のCanvasTexture含む）を
// すべてGPUメモリから明示的に破棄する。
// これを呼ばないと scene.remove() だけでは解放されず、
// カスタマイズ操作のたびにキャラクター1体分がリークし続ける。
function disposeObject3D(root) {
    if (!root) return;
    root.traverse((node) => {
        if (node.geometry) {
            node.geometry.dispose();
        }
        if (node.material) {
            const mats = Array.isArray(node.material) ? node.material : [node.material];
            mats.forEach((mat) => {
                ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'emissiveMap', 'alphaMap', 'aoMap', 'bumpMap']
                    .forEach((key) => { if (mat[key]) mat[key].dispose(); });
                mat.dispose();
            });
        }
    });
}

