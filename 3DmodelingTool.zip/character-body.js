function createCharacter(data) {
    // ★後方互換：古い保存データにtopWearが無い場合、shirtColorから推定する
    if (data.topWear === undefined) {
        data.topWear = (data.shirtColor && data.shirtColor !== 'none') ? 'shirt' : 'none';
    }
    if (characterGroup) {
        scene.remove(characterGroup);
        disposeObject3D(characterGroup);
        characterGroup = null;
    }
    characterGroup = new THREE.Group();
    animatedParts = { arms: [], legs: [] };

    // ★ 位置変更：おにぎり型（卵型）を作る共通関数を、頭や耳の処理でも使えるように上に移動しました
    function createEggGeo(scaleX, scaleY, scaleZ, taperY) {
        const geo = new THREE.SphereGeometry(1, 32, 32);
        const p = geo.attributes.position;
        for (let i = 0; i < p.count; i++) {
            let x = p.getX(i); let y = p.getY(i); let z = p.getZ(i);
            let taper = 1.0 - (y * taperY); 
            p.setX(i, x * scaleX * taper);
            p.setY(i, y * scaleY);
            p.setZ(i, z * scaleZ); 
        }
        geo.computeVertexNormals();
        return geo;
    }

    const skinMat = new THREE.MeshLambertMaterial({ color: data.bodyColor });
    const clothesMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const hairMat = new THREE.MeshLambertMaterial({ color: data.hairColor || '#333333' });

    // --- 頭 ---
    const headGeo = new THREE.SphereGeometry(1, 32, 32);
    const pos = headGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
        let y = pos.getY(i);
        if (y < 0) {
            let factor = 1.0 - (Math.abs(y) * (1.0 - data.jawWidth));
            pos.setX(i, pos.getX(i) * factor); 
            pos.setZ(i, pos.getZ(i) * factor + Math.abs(y) * 0.12); 
        }
    }
    headGeo.computeVertexNormals();
    const head = new THREE.Mesh(headGeo, skinMat);
    head.scale.set(data.headScaleX, data.headScaleY, data.headScaleX);
    // =============================================================
    // 首 → 頭 の順で構築（headPivot は neckPivot の子）
    // 構造: characterGroup → neckPivot → [首メッシュ群, headPivot → head]
    // neckPivotを回転すると首＋頭が一緒に動く
    // =============================================================

    // --- 首 ---
    const neckR = 0.27;
    const neckCylLen = neckR * 2 / 3; // 0.18
    const neckCylBottom = 2.42 + neckR; // 2.69 = 首の根元Y

    // neckPivot: 首の根元(y=2.69)を回転中心とする親グループ
    const neckPivot = new THREE.Group();
    neckPivot.position.set(0, neckCylBottom, 0.03);
    characterGroup.add(neckPivot);
    animatedParts.neck = neckPivot;

    // 胸側半球（neckPivot相対 y=0 = 首の根元）
    const neckBottomGeo = new THREE.SphereGeometry(neckR, 16, 8);
    const neckBottom = new THREE.Mesh(neckBottomGeo, skinMat);
    neckBottom.position.set(0, 0, 0);
    neckPivot.add(neckBottom);

    // 円筒本体
    const neckCylGeo = new THREE.CylinderGeometry(neckR, neckR, neckCylLen, 16, 1, true);
    const neckCyl = new THREE.Mesh(neckCylGeo, skinMat);
    neckCyl.position.set(0, neckCylLen * 0.5, 0);
    neckPivot.add(neckCyl);

    // 頭側半球
    const neckCylTop = neckCylLen;
    const neckTopGeo = new THREE.SphereGeometry(neckR, 16, 8);
    const neckTop = new THREE.Mesh(neckTopGeo, skinMat);
    neckTop.position.set(0, neckCylTop, 0);
    neckPivot.add(neckTop);

    // --- 頭（neckPivotの子として追従） ---
    // headPivot は neckPivot 相対座標で、頭の中心位置に置く
    // neckPivot のワールド座標 y = 2.69、頭中心 y ≈ 2.87 + 0.70*scaleY
    const headBaseY = 2.87;
    const headRadius = 0.70;
    const headCenterWorld = headBaseY + headRadius * data.headScaleY;
    const headCenterLocal = headCenterWorld - neckCylBottom; // neckPivot相対Y

    // headPivot: neckPivotの子、頭の中心を回転ピボットにする
    const headPivot = new THREE.Group();
    headPivot.position.set(0, headCenterLocal, 0.15); // z=0.15は元の頭のオフセット
    neckPivot.add(headPivot); // ★ neckPivotの子にする
    animatedParts.head = headPivot;

    // head メッシュは headPivot の原点（中心）に配置
    head.position.set(0, 0, 0);
    head.rotation.x = 0.05;
    headPivot.add(head);

    // ★表情システム改修：ここでは常にDEFAULT_EXPRESSION（キャラタブの固定デフォルト表情）
    //   でメッシュを生成する。ポーズ専用の表情は、この直後に呼ばれる
    //   window._reapplyCurrentExpression()がmaterial.mapを直接差し替えて反映する。
    const eyeMat = new THREE.MeshBasicMaterial({ map: createEyeTexture(DEFAULT_EXPRESSION.eyeType, data.eyeColor), transparent: true });
    const eyes = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.9), eyeMat);
    eyes.position.set(0, -0.05, 1.02); head.add(eyes);

    const mouthMat = new THREE.MeshBasicMaterial({ map: createMouthTexture(DEFAULT_EXPRESSION.mouthType), transparent: true });
    const mouth = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.25), mouthMat);
    mouth.position.set(0, -0.45, 0.98); head.add(mouth);

    const eyebrowMat = new THREE.MeshBasicMaterial({ map: createEyebrowTexture(DEFAULT_EXPRESSION.eyebrowType), transparent: true });
    const eyebrows = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.7), eyebrowMat);
    eyebrows.position.set(0, 0.42, 1.0); head.add(eyebrows);

    // 表情システム用に参照を公開（ポーズ切替時、キャラ全体を再構築せず
    // これらのMaterialのmapだけを直接差し替えるために使う。GLB出力時にも
    // 「デフォルト表情メッシュ」の可視トグル対象として参照される）
    animatedParts.face = { eyes: eyeMat, mouth: mouthMat, eyebrow: eyebrowMat, eyesMesh: eyes, mouthMesh: mouth, eyebrowMesh: eyebrows };

    // ★ 耳の生成
    if (data.earType === 'human' || data.earType === 'elf') {
        let earGeo;
        if (data.earType === 'human') {
            earGeo = createEggGeo(0.14, 0.24, 0.16, 0.3);
        } else {
            earGeo = createEggGeo(0.14, 0.55, 0.14, 0.65);
        }
        const earL = new THREE.Mesh(earGeo, skinMat);
        if (data.earType === 'human') {
            earL.position.set(0.92, -0.1, -0.05);
            earL.rotation.set(0.1, -0.2, -0.2);
        } else {
            earL.position.set(0.92, 0.05, -0.15);
            earL.rotation.set(-0.15, -0.4, -0.6);
        }
        head.add(earL);

        const earR = new THREE.Mesh(earGeo, skinMat);
        if (data.earType === 'human') {
            earR.position.set(-0.92, -0.1, -0.05);
            earR.rotation.set(0.1, 0.2, 0.2);
        } else {
            earR.position.set(-0.92, 0.05, -0.15);
            earR.rotation.set(-0.15, 0.4, 0.6);
        }
        head.add(earR);
    }

    // --- 髪の毛 ---
    const hairGroup = new THREE.Group();
    hairGroup.add(new THREE.Mesh(new THREE.SphereGeometry(1.05, 32, 32, 0, Math.PI * 2, 0, Math.PI / 1.95), hairMat));

    if (data.hairType === 'short01') {
        const sideGeo = new THREE.ConeGeometry(0.25, 0.8, 16);
        const sideL = new THREE.Mesh(sideGeo, hairMat); sideL.position.set(0.95, -0.4, 0.1); sideL.rotation.z = -0.3;
        const sideR = new THREE.Mesh(sideGeo, hairMat); sideR.position.set(-0.95, -0.4, 0.1); sideR.rotation.z = 0.3;
        hairGroup.add(sideL, sideR);
    } else if (data.hairType === 'long01') {
        // --- 後頭部から毛先まで、継ぎ目のない1本のジオメトリで作成 ---
        // 半径・前後の潰し・後方カーブを高さごとに滑らかに変化させ、
        // 「肩までは緩やかな板」「腰までは丸みのある円錐」の見た目を継ぎ目なく再現する。
        const lerp = (a, b, t) => a + (b - a) * t;
        const totalLen = 3.0;
        const shoulderFrac = 0.43; // 全体のうち肩までが占める割合
        const hairOrigin = { x: 0, y: 0.2, z: -0.45 }; // 頭の中心から見たこの髪メッシュの原点位置
        const headRadius = 1.05; // 頭球のサイズと合わせる

        const longHairGeo = new THREE.CylinderGeometry(1, 1, totalLen, 20, 16); // 半径1固定、頂点ごとに再スケールする
        longHairGeo.translate(0, -totalLen / 2, 0); // 上端(後頭部側)をy=0に揃える
        const lhPos = longHairGeo.attributes.position;
        for (let i = 0; i < lhPos.count; i++) {
            const yOrig = lhPos.getY(i);
            const t = Math.min(1, Math.max(0, -yOrig / totalLen)); // 0(頭側)〜1(毛先)

            // 半径プロファイル：頭元→肩でわずかに広がり、肩→毛先で丸みを持って細くなる
            let r;
            if (t <= shoulderFrac) {
                r = lerp(1.0, 1.08, t / shoulderFrac);
            } else {
                const u = (t - shoulderFrac) / (1 - shoulderFrac);
                r = lerp(1.08, 0.08, Math.pow(u, 0.7));
            }

            // 前後の潰し具合：頭付近は丸く、肩あたりから薄い板状に移行
            const flat = lerp(1.0, 0.45, Math.min(1, t / shoulderFrac));

            let x = lhPos.getX(i) * r;
            let y = yOrig;
            let z = lhPos.getZ(i) * r * flat;
            z -= Math.pow(t, 1.3) * 0.35; // 下にいくほど後方へゆるやかにカーブ

            // 根元(t=0付近)だけ頭の球面にぴったり吸着させ、段差をなくす
            const snapRaw = Math.min(1, Math.max(0, 1 - t / 0.18));
            const snap = snapRaw * snapRaw * (3 - 2 * snapRaw); // なめらかに減衰させる(smoothstep)
            if (snap > 0) {
                const hx = x + hairOrigin.x, hy = y + hairOrigin.y, hz = z + hairOrigin.z; // 頭中心基準の座標
                const dist = Math.sqrt(hx * hx + hy * hy + hz * hz) || 1;
                const s = headRadius / dist;
                const targetX = hx * s - hairOrigin.x;
                const targetY = hy * s - hairOrigin.y;
                const targetZ = hz * s - hairOrigin.z;
                x += (targetX - x) * snap;
                y += (targetY - y) * snap;
                z += (targetZ - z) * snap;
            }

            lhPos.setX(i, x);
            lhPos.setY(i, y);
            lhPos.setZ(i, z);
        }
        longHairGeo.computeVertexNormals();
        const longHair = new THREE.Mesh(longHairGeo, hairMat);
        longHair.position.set(hairOrigin.x, hairOrigin.y, hairOrigin.z);
        hairGroup.add(longHair);

        // --- 毛先を少し丸める小さな球（親を髪本体にして、常にぴったり付いてくるようにする） ---
        const hairTipCapGeo = new THREE.SphereGeometry(0.09, 12, 10);
        const hairTipCap = new THREE.Mesh(hairTipCapGeo, hairMat);
        hairTipCap.position.set(0, -totalLen, -0.35); // longHairからの相対座標（毛先の中心と一致）
        hairTipCap.scale.set(1, 1, 0.45);
        longHair.add(hairTipCap);
    } else if (data.hairType === 'ponytail01') {
        // --- 前髪（short01と同じ形状・配置） ---
        const sideGeo = new THREE.ConeGeometry(0.25, 0.8, 16);
        const sideL = new THREE.Mesh(sideGeo, hairMat); sideL.position.set(0.95, -0.4, 0.1); sideL.rotation.z = -0.3;
        const sideR = new THREE.Mesh(sideGeo, hairMat); sideR.position.set(-0.95, -0.4, 0.1); sideR.rotation.z = 0.3;
        hairGroup.add(sideL, sideR);

        // --- 後頭部：丸い髪ボリューム（頭のベースキャップと同じ半径でシームレスに繋げ、ポニーテール根元まで深く覆う） ---
        const backVolGeo = new THREE.SphereGeometry(1.1, 32, 32);
        const backVol = new THREE.Mesh(backVolGeo, hairMat);
        backVol.position.set(0, 0.15, -0.4);
        backVol.scale.set(1, 1, 0.62); // 前後方向を潰して後頭部だけに留めつつ、根元までしっかり覆う余裕を持たせる
        hairGroup.add(backVol);

        // --- ポニーテール根元（髪ゴム部分の土台となるピボット。後頭部ボリュームの表面付近まで少し外に出す） ---
        const ponyRoot = new THREE.Group();
        ponyRoot.position.set(0, 0.3, -1.05);
        ponyRoot.scale.set(2, 2, 2); // ポニーテール全体を倍サイズに
        hairGroup.add(ponyRoot);

        // 根元の丸いふくらみ（涙滴の上部分）：後頭部ボリュームと重ねて地肌が見えないようにしつつ、外にしっかり見せる
        const poofGeo = new THREE.SphereGeometry(0.32, 20, 16);
        const poof = new THREE.Mesh(poofGeo, hairMat);
        poof.position.set(0, 0.05, 0.1);
        ponyRoot.add(poof);

        // 髪ゴム（暗め茶色）：ふくらみとテールの境目にはめる。前後の髪より少し太くして帯状にはっきり見せる
        const tieMat = new THREE.MeshLambertMaterial({ color: 0x4a2f1c });
        const tie = new THREE.Mesh(new THREE.SphereGeometry(0.38, 20, 12), tieMat);
        tie.scale.set(1, 0.42, 1);
        ponyRoot.add(tie);

        // ポニーテール本体：涙滴型（上太・下細）のシリンダーを後方へカーブ変形
        const ponyBodyLen = 1.45;
        const ponyGeo = new THREE.CylinderGeometry(0.3, 0.07, ponyBodyLen, 20, 14);
        ponyGeo.translate(0, -ponyBodyLen / 2 - 0.05, 0); // 根元をponyRoot原点直下に接続
        const ponyPos = ponyGeo.attributes.position;
        for (let i = 0; i < ponyPos.count; i++) {
            const y = ponyPos.getY(i);
            const z = ponyPos.getZ(i);
            ponyPos.setZ(i, z + y * 0.15); // 下にいくほど後方へカーブ
        }
        ponyGeo.computeVertexNormals();
        const ponyBody = new THREE.Mesh(ponyGeo, hairMat);
        ponyRoot.add(ponyBody);

        // 毛先：先端を細くするコーン
        const tipY = -(ponyBodyLen + 0.05);
        const tipCurveZ = tipY * 0.15;
        const tipGeo = new THREE.ConeGeometry(0.09, 0.3, 16);
        const tip = new THREE.Mesh(tipGeo, hairMat);
        tip.position.set(0, tipY - 0.15, tipCurveZ);
        tip.rotation.x = Math.PI; // 先端が下向きになるよう反転
        ponyRoot.add(tip);

        animatedParts.ponyTail = ponyRoot;
    } else if (data.hairType === 'bun01') {
        // --- 前髪（ponytail01/short01と同じ形状・配置を流用） ---
        const sideGeo = new THREE.ConeGeometry(0.25, 0.8, 16);
        const sideL = new THREE.Mesh(sideGeo, hairMat); sideL.position.set(0.95, -0.4, 0.1); sideL.rotation.z = -0.3;
        const sideR = new THREE.Mesh(sideGeo, hairMat); sideR.position.set(-0.95, -0.4, 0.1); sideR.rotation.z = 0.3;
        hairGroup.add(sideL, sideR);

        // --- 後頭部：丸い髪ボリューム（ponytail01と同じ形状を流用。髪留め・しっぽは付けない） ---
        const backVolGeo = new THREE.SphereGeometry(1.1, 32, 32);
        const backVol = new THREE.Mesh(backVolGeo, hairMat);
        backVol.position.set(0, 0.15, -0.4);
        backVol.scale.set(1, 1, 0.62);
        hairGroup.add(backVol);

        // --- お団子：頭頂部中心より少し後方へ配置。2個をわずかに重ねて自然な巻き髪の丸みを出す ---
        const bunGeo = new THREE.SphereGeometry(0.42, 20, 16);
        const bun = new THREE.Mesh(bunGeo, hairMat);
        bun.position.set(0, 0.78, -0.82);
        bun.scale.set(1.0, 0.9, 0.9);
        hairGroup.add(bun);
    }
    head.add(hairGroup);

    // ── 軽装プレートアーマー：ヘルメット（装着時のみ生成し、髪の上から被せる） ──
    if (data.hasHelmet) {
        const helmet = createHelmet();
        head.add(helmet);
        animatedParts.helmet = helmet;
    } else {
        animatedParts.helmet = null;
    }

    // --- 胴体 ---
    // 臀部：胸部と同じ形状・サイズ
    const pelvisGeo = new THREE.SphereGeometry(0.52, 20, 16);
    const pelvis = new THREE.Mesh(pelvisGeo, skinMat);
    pelvis.scale.set(1.15, 0.80, 0.72); // 胸部と同じ楕円球
    pelvis.position.y = 1.1; 
    characterGroup.add(pelvis);

    const belly = new THREE.Mesh(new THREE.SphereGeometry(0.38, 16, 16), skinMat); 
    belly.scale.set(1.0, 1.0, 0.72); // 前後を薄くして背中から飛び出さないように
    belly.position.y = 1.5; 
    animatedParts.belly = belly;
    characterGroup.add(belly);

    // chest: 前後につぶれた楕円球（X広め・Y中・Z薄め）
    const chestGeo = new THREE.SphereGeometry(0.52, 20, 16);
    const chest = new THREE.Mesh(chestGeo, skinMat);
    chest.scale.set(1.15, 0.80, 0.72); // 横広・前後薄の楕円球
    chest.position.y = 2.0; 
    animatedParts.chest = chest;
    characterGroup.add(chest);

    // --- 服グループ ---
    // clothesGroupはbodyGroupと完全に分離した独立グループ
    // 将来「鎧」「ローブ」等への拡張もここに追加するだけでOK
    // 下半身装備（ズボン／スカート）は同時装備禁止。bottomWearで切替
    // ズボンの太もも/膝/すね/裾はcreateLeg()内でボーン直下に生成済み
    // ヒップ（pelvis）部の下半身装備はcharacterGroup直下に追加
    if (data.bottomWear === 'pants' && data.pantsColor && data.pantsColor !== 'none') {
        createPants(data.pantsColor, characterGroup, pelvis);
        // ウエスト帯は削除（bellyまで食い込むため）
    } else if ((data.bottomWear === 'skirt' || data.bottomWear === 'longskirt') && data.skirtColor && data.skirtColor !== 'none') {
        // ★ロングスカートは「スカート本体（骨盤〜膝ヒダ）」をそのまま流用し、
        //   そこに新規の裾延長パーツ(createLongSkirtExtension)を継ぎ足す方式なので、
        //   ここのブルマー処理も通常のスカートと全く同じでよい。
        // 臀部を非表示にすると、脚を高く上げるポーズの時に
        // 「脚だけが宙に浮いている」ように見えてしまうため、
        // 隠す代わりに色を変えて「ブルマーを履いている」体にする。
        // pelvisはskinMatを他の部位（頭・腕・脚など）と共有しているため、
        // pelvisだけ専用のMaterialに差し替える（skinMat自体は変更しない）。
        pelvis.material = new THREE.MeshLambertMaterial({ color: 0x2244aa }); // ブルマー色（紺）
        // スカート本体（動的追従版）はcreateLeg()×2実行後でないと
        // 左右の膝ボーン(hip/knee)を参照できないため、下方の
        // 「animatedParts.legs.push(createLeg(...))」の直後で
        // createDynamicSkirt()を呼び出している（このifブロックでは
        // pelvisの色替えだけを行う）。
    } else if (data.bottomWear === 'culotte' && data.skirtColor && data.skirtColor !== 'none') {
        // 腰まわりはズボンと同じ球体カバーを流用（脚に追従するスカート部はcreateLeg内で生成）
        createPants(data.skirtColor, characterGroup, pelvis);
    }
    if (data.topWear === 'shirt' && data.shirtColor && data.shirtColor !== 'none') {
        const sg = createTShirt(data.shirtColor, characterGroup, data);
        if (sg) sg.renderOrder = 2;
    } else if (data.topWear === 'armor') {
        const bp = createBreastplate(data, characterGroup);
        if (bp) bp.renderOrder = 2;
    }

    // 胸の大きさ（バスト）の表現
    if (data.bustSize > 0) {
        const b = data.bustSize;
        const bustRadius = 0.22 * b; // 胸球体の半径
        // 飛び出し量の上限 = 半径の2/3（それ以上は球体が露出して不自然）
        const pRaw = data.bustProtrude;
        const pMax = bustRadius; // 最大=半球（球体の半径分だけ前に出る）
        const p = Math.min(pRaw, pMax);
        const bustGeo = new THREE.SphereGeometry(bustRadius, 16, 16); // 完全な球体

        // 左胸
        const bustL = new THREE.Mesh(bustGeo, skinMat);
        bustL.position.set(0.17, -0.05, p); 
        bustL.rotation.x = Math.PI / 2.2;     
        bustL.rotation.y = -0.15;             
        bustL.rotation.z = -0.2;              
        chest.add(bustL);

        // 右胸
        const bustR = new THREE.Mesh(bustGeo, skinMat);
        bustR.position.set(-0.17, -0.05, p); 
        bustR.rotation.x = Math.PI / 2.2;
        bustR.rotation.y = 0.15;              
        bustR.rotation.z = 0.2;               
        chest.add(bustR);
    }

    // --- 関節ジオメトリ ---
    const bigJointGeo = new THREE.SphereGeometry(0.2, 16, 16); 
    const smallJointGeo = new THREE.SphereGeometry(0.16, 16, 16); 

    // 篭手（前腕当て・手甲）用マテリアル：左右のcreateArm()呼び出しで共有する
    let armPlateMat = null, armTrimMat = null;
    if (data.topWear === 'armor') {
        armPlateMat = new THREE.MeshLambertMaterial({ color: data.plateColor || '#d8dce0' });
        armTrimMat  = new THREE.MeshLambertMaterial({ color: data.plateTrimColor || '#d4af37' });
    }

    // ★ 修正：腕用と脚用でジオメトリを別々に生成する
    // translate()はジオメトリ自体を書き換える破壊的操作のため、共有すると2つ目がずれるバグがあった
    function createLimbGeo() {
        const geo = new THREE.CylinderGeometry(0.16, 0.13, 0.8, 16);
        geo.translate(0, -0.4, 0);
        return geo;
    }

    function createArm(xPos) {
        const shoulder = new THREE.Mesh(bigJointGeo, skinMat); 
        shoulder.position.set(xPos, 2.15, 0); // 肩を下げてなで肩に
        const upperArm = new THREE.Mesh(createLimbGeo(), skinMat); 
        shoulder.add(upperArm);
        const elbow = new THREE.Mesh(smallJointGeo, skinMat); 
        elbow.position.set(0, -0.8, 0);
        upperArm.add(elbow);
        const foreArm = new THREE.Mesh(createLimbGeo(), skinMat); 
        elbow.add(foreArm);
        const wrist = new THREE.Mesh(smallJointGeo, skinMat); 
        wrist.position.set(0, -0.8, 0);
        foreArm.add(wrist);

        // ── 軽装プレートアーマー：篭手（前腕当て＋手甲） ──
        // foreArm/wristはこの関数内で今まさに生成されたばかりなので、
        // ここで直接addすれば確実にタイミング問題を回避できる
        //
        // ★修正：以前は手首を覆う「カフ」と縁取りリングをwrist(手首)側に付けていたため、
        //   手首を捻る/曲げるポーズにすると前腕当てから分離して腕の外側に飛び出して見えるバグがあった。
        //   → カフとリングは前腕当て側（foreArm、手首の回転に巻き込まれない）に固定し、
        //     wristの子には「手を覆う丸いキャップ」だけを残す（これは手と一緒に回転してよい部分）。
        if (data.topWear === 'armor' && armPlateMat && armTrimMat) {
            // 前腕当て（ForeArmArmor）：foreArmに固定。手首の少し上まで伸ばす
            const vambraceGeo = new THREE.CylinderGeometry(0.19, 0.175, 0.46, 16);
            const vambrace = new THREE.Mesh(vambraceGeo, armPlateMat);
            vambrace.position.y = -0.55;
            foreArm.add(vambrace);

            // 前腕当て下端（手首側）の金縁トリム。foreArm側に固定＝手首の回転の影響を受けない
            const vambraceRing = new THREE.Mesh(new THREE.TorusGeometry(0.175, 0.025, 8, 20), armTrimMat);
            vambraceRing.rotation.x = Math.PI / 2;
            vambraceRing.position.y = -0.78;
            foreArm.add(vambraceRing);

            // 手甲（HandArmor）：wrist関節を覆う丸いキャップのみ。手の回転に追従してよい部分
            const handCapGeo = new THREE.SphereGeometry(0.19, 14, 12, 0, Math.PI * 2, 0, Math.PI / 1.7);
            const handCap = new THREE.Mesh(handCapGeo, armPlateMat);
            handCap.name = 'handArmor';
            handCap.position.y = -0.02;
            wrist.add(handCap);
        }

        characterGroup.add(shoulder);
        return { root: shoulder, joint: elbow, wrist: wrist };
    }

    // ── 小道具：剣（右手用） ──
    // シンプルなプリミティブ（柄+鍔+刃）で構成した剣を1つのグループにまとめる
    function createSword(scale = 1) {
        const sword = new THREE.Group();
        sword.name = 'swordRight';

        const handleMat = new THREE.MeshLambertMaterial({ color: 0x4a3320 }); // 柄：茶色
        const guardMat   = new THREE.MeshLambertMaterial({ color: 0xc8a020 }); // 鍔：金色
        const bladeMat   = new THREE.MeshLambertMaterial({ color: 0xd8dce0 }); // 刃：銀色

        // 柄（グリップ）：握り込む部分。wristのローカルY軸下方向に伸ばす
        const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.4, 12), handleMat);
        handle.position.set(0, 0, 0);
        sword.add(handle);

        // 鍔（ガード）：柄と刃の境目。幅広の大剣らしく横に張り出す
        const guard = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.06, 0.1), guardMat);
        guard.position.set(0, 0.215, 0);
        sword.add(guard);

        // 刃：鍔から上に伸びる、幅広で厚みのある刀身
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.5, 0.045), bladeMat);
        blade.position.set(0, 0.98, 0);
        sword.add(blade);

        // 刃先（先端を尖らせる）：剣身と同じ幅・厚みの平たい三角形を押し出して作る（円錐だと槍のように見えるため）
        const tipWidth = 0.2;   // 刃の幅と同じ
        const tipHeight = 0.22;
        const tipThickness = 0.045; // 刃の厚みと同じ
        const tipShape = new THREE.Shape();
        tipShape.moveTo(-tipWidth / 2, 0);
        tipShape.lineTo(tipWidth / 2, 0);
        tipShape.lineTo(0, tipHeight);
        tipShape.closePath();
        const tipGeo = new THREE.ExtrudeGeometry(tipShape, { depth: tipThickness, bevelEnabled: false });
        tipGeo.translate(0, 0, -tipThickness / 2); // 厚みの中心を原点に合わせる
        const tip = new THREE.Mesh(tipGeo, bladeMat);
        tip.position.set(0, 1.73, 0);
        sword.add(tip);

        // scale!==1の場合、全体を一括拡大（大剣は通常の剣の2倍サイズ）
        if (scale !== 1) sword.scale.setScalar(scale);

        return sword;
    }

    // ── 小道具：盾（左手用） ──
    // 丸型ファンタジーシールド：外枠リング＋本体＋中央ボス＋裏側グリップ
    function createShield() {
        const shield = new THREE.Group();
        shield.name = 'shieldLeft';

        const rimMat  = new THREE.MeshLambertMaterial({ color: 0xd4af37 }); // 縁：金色
        const faceMat = new THREE.MeshLambertMaterial({ color: 0x3d5a99 }); // 面：青
        const bossMat = new THREE.MeshLambertMaterial({ color: 0xf0c94a }); // 中央ボス：金色

        // 外枠リング
        const rim = new THREE.Mesh(new THREE.TorusGeometry(0.66, 0.08, 12, 24), rimMat);
        shield.add(rim);

        // シールド本体（厚みのある円盤）
        const face = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, 0.1, 24), faceMat);
        face.rotation.x = Math.PI / 2;
        shield.add(face);

        // 中央ボス（半球状のふくらみ）
        const boss = new THREE.Mesh(new THREE.SphereGeometry(0.24, 16, 16), bossMat);
        boss.scale.z = 0.5;
        boss.position.z = 0.08;
        shield.add(boss);

        // 裏側グリップ（持ち手）
        const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 10), rimMat);
        grip.rotation.x = Math.PI / 2;
        grip.position.z = -0.06;
        shield.add(grip);

        return shield;
    }

    // ── 軽装プレートアーマー：ヘルメット ──
    // 頭頂〜額の上あたりまでを覆うドーム状の兜。前は開けて素顔が見えるオープンフェイス構造。
    // こめかみ横に小さな側面プレートを追加。耳や側頭部・後頭部の髪はそのまま覗かせる。
    function createHelmet() {
        const helmet = new THREE.Group();
        helmet.name = 'helmet';

        const plateColor = data.plateColor || '#d8dce0';
        const trimColor  = data.plateTrimColor || '#d4af37';
        // ★修正：MeshStandardMaterial(metalness)は環境マップの無いこのシーンでは
        //   ハイライト以外が真っ黒に見えてしまうため、他の部位と同じLambertに変更
        const plateMat = new THREE.MeshLambertMaterial({ color: plateColor });
        const trimMat  = new THREE.MeshLambertMaterial({ color: trimColor });

        // 本体ドーム：頭頂から額の上あたりまでを覆う（前面は開けて素顔を見せる）
        // ★修正：後ろ髪は将来編集予定＆ロングヘアで干渉してバグるため、
        //   phiStart/phiLengthで水平方向を前半分（左耳〜正面〜右耳）だけに制限する
        const domeThetaLen = Math.PI / 2.7; // 約67°、髪の帽子(π/1.95)より浅く覆う
        const domeR = 1.16; // 髪の帽子(半径1.05)より一回り大きく、外側に被せる
        const domePhiStart  = 0;
        const domePhiLength = Math.PI; // 前半分のみ（後頭部には回り込まない）
        const domeGeo = new THREE.SphereGeometry(domeR, 24, 16, domePhiStart, domePhiLength, 0, domeThetaLen);
        const dome = new THREE.Mesh(domeGeo, plateMat);
        helmet.add(dome);

        // ドーム下端に沿った金色の縁取りリング（同じく前半分のみの円弧）
        const edgeY = domeR * Math.cos(domeThetaLen);
        const edgeR = domeR * Math.sin(domeThetaLen);
        const trimRing = new THREE.Mesh(new THREE.TorusGeometry(edgeR, 0.045, 10, 32, Math.PI), trimMat);
        trimRing.position.y = edgeY;
        trimRing.rotation.x = Math.PI / 2;
        helmet.add(trimRing);

        // こめかみ横の小さな側面プレート（耳の少し外側。左右対称）
        // ★修正：以前は顔の前に垂れ下がる巨大な黒い板になっていたため、
        //   耳と同程度のサイズに縮小し、頭の側面に沿う位置へ移動
        function createTemplePlate(sign) {
            const plateGeo = createEggGeo(0.16, 0.22, 0.09, 0.3);
            const plate = new THREE.Mesh(plateGeo, plateMat);
            plate.position.set(sign * 1.02, edgeY - 0.10, 0.12);
            plate.rotation.set(0.05, sign * -0.25, sign * 0.1);
            return plate;
        }
        helmet.add(createTemplePlate(1));
        helmet.add(createTemplePlate(-1));

        return helmet;
    }

    function createLeg(xPos, pelvisMesh, pantsColor, culotteColor) {
        const hasPants = pantsColor && pantsColor !== 'none';
        const hasCulotte = culotteColor && culotteColor !== 'none';
        const pantsMat = hasPants ? new THREE.MeshLambertMaterial({ color: pantsColor }) : null;
        const hipR = 0.22;

        // ── hipはGroupにしてMeshを子にする（visible=falseの連鎖を防ぐ） ──
        const hip = new THREE.Group();
        hip.position.set(xPos, 0.54, 0.0);

        const hipMesh = new THREE.Mesh(new THREE.SphereGeometry(hipR, 16, 16), skinMat);
        hipMesh.visible = !(hasPants || hasCulotte);
        hip.add(hipMesh);

        // 膝関節：Groupにする
        const kneeR = 0.15;
        const knee = new THREE.Group();
        knee.position.set(0, -0.85, 0);
        hip.add(knee);

        const kneeMesh = new THREE.Mesh(new THREE.SphereGeometry(kneeR, 16, 16), skinMat);
        kneeMesh.visible = !hasPants;
        knee.add(kneeMesh);

        // 太もも
        const thighLen = 0.85;
        const thighTopR  = hipR * 1.1;
        const thighBotR  = kneeR * 0.75;
        const thighGeo = new THREE.CylinderGeometry(thighTopR, thighBotR, thighLen, 16);
        thighGeo.translate(0, -thighLen / 2, 0);
        const thigh = new THREE.Mesh(thighGeo, skinMat);
        thigh.visible = !hasPants;
        hip.add(thigh);

        // ふくらはぎ
        const calfLen = 0.85;
        const calfTopR  = kneeR * 0.85;
        const calfBotR  = 0.13;
        const calfGeo = new THREE.CylinderGeometry(calfTopR, calfBotR, calfLen, 16);
        calfGeo.translate(0, -calfLen / 2, 0);
        const calf = new THREE.Mesh(calfGeo, skinMat);
        calf.visible = !hasPants;
        knee.add(calf);

        // ── 足首（関節球体） ──
        const ankleR = 0.14;
        const ankle = new THREE.Mesh(new THREE.SphereGeometry(ankleR, 16, 16), skinMat);
        ankle.position.set(0, -calfLen, 0);
        knee.add(ankle);

        // ── ズボンパーツ（ボーン直下でポーズ追従） ──
        if (hasPants) {
            // ヒップ（hip球体を包む）
            const pHipGeo = new THREE.SphereGeometry(hipR + 0.045, 16, 16);
            const pHip = new THREE.Mesh(pHipGeo, pantsMat);
            pHip.position.set(0, 0, 0); // hip原点に合わせる
            hip.add(pHip);

            // 太もも（thighを包む円錐台）
            const pThighGeo = new THREE.CylinderGeometry(
                thighTopR + 0.04, thighBotR + 0.04, thighLen, 20);
            pThighGeo.translate(0, -thighLen / 2, 0);
            const pThigh = new THREE.Mesh(pThighGeo, pantsMat);
            hip.add(pThigh);

            // 膝（knee球体を包む）
            const pKneeGeo = new THREE.SphereGeometry(kneeR + 0.04, 16, 16);
            const pKnee = new THREE.Mesh(pKneeGeo, pantsMat);
            pKnee.position.set(0, -0.85, 0); // knee.position と同じ
            hip.add(pKnee);

            // すね（calfを包む円錐台）
            const pCalfGeo = new THREE.CylinderGeometry(
                calfTopR + 0.04, calfBotR + 0.04, calfLen, 20);
            pCalfGeo.translate(0, -calfLen / 2, 0);
            const pCalf = new THREE.Mesh(pCalfGeo, pantsMat);
            // knee直下のcalfと同じ座標系
            knee.add(pCalf);

            // 裾（すね下端を閉じる円盤）
            const pHemGeo = new THREE.CircleGeometry(calfBotR + 0.04, 20);
            const pHem = new THREE.Mesh(pHemGeo, pantsMat);
            pHem.rotation.x = Math.PI / 2;
            pHem.position.set(0, -calfLen, 0);
            knee.add(pHem);
        }

        // ── キュロット（分割スカート）：thigh(hip)の子として追加し、脚の動きに追従させる ──
        // 太もも半ばまでで留めて裾を大きく広げることで、キック等で足がスカートを
        // 貫通して見えるのを防ぐ（膝から下は素足のまま見せてスカートらしさを保つ）。
        if (hasCulotte) {
            const culotteMat = new THREE.MeshLambertMaterial({ color: culotteColor, side: THREE.DoubleSide });

            // 腰の継ぎ目（hip球のカバー。pPelvisとの段差を出さないよう少し大きめ）
            const cHipGeo = new THREE.SphereGeometry(hipR + 0.05, 16, 16);
            const cHip = new THREE.Mesh(cHipGeo, culotteMat);
            hip.add(cHip);

            // 太もも部：円錐台をスカート風にフレアさせる（上は太ももに沿わせ、下は大きく広げる）
            const cTopR = thighTopR + 0.07;
            const cBotR = thighBotR + 0.30;  // 裾を広げて脚の振り幅を吸収
            const cLen  = thighLen * 0.62;   // 膝までは届かせず太もも半ばで終える
            const culotteGeo = new THREE.CylinderGeometry(cTopR, cBotR, cLen, 10, 3);
            culotteGeo.translate(0, -cLen / 2, 0);

            // プリーツ風の軽い波打ち（既存スカートと同じ手法・低ポリのまま質感を出す）
            const cPos = culotteGeo.attributes.position;
            for (let i = 0; i < cPos.count; i++) {
                const cx = cPos.getX(i), cz = cPos.getZ(i);
                const angle = Math.atan2(cz, cx);
                const pleat = 1 + Math.sin(angle * 8) * 0.03;
                cPos.setX(i, cx * pleat);
                cPos.setZ(i, cz * pleat);
            }
            cPos.needsUpdate = true;
            culotteGeo.computeVertexNormals();

            const culotteThigh = new THREE.Mesh(culotteGeo, culotteMat);
            culotteThigh.scale.z = 0.88; // 前後をわずかに薄くしてゴツく見えないように
            culotteThigh.rotation.z = (xPos > 0 ? -1 : 1) * 0.07; // 左右で外側へわずかに開く
            hip.add(culotteThigh);

            // 裾リング（厚み付け）
            const cHemGeo = new THREE.TorusGeometry(cBotR, 0.025, 6, 16);
            const cHem = new THREE.Mesh(cHemGeo, culotteMat);
            cHem.rotation.x = Math.PI / 2;
            cHem.scale.z = 0.88;
            cHem.position.y = -cLen;
            hip.add(cHem);
        }

        // ── 軽装プレートアーマー：腰タセット（左右独立・前は開けたまま） ──
        // 【設計方針】
        //   ・キュロットと同じ「太もも半ばで留めて裾を広げる」構造を流用し、
        //     脚を高く上げても貫通しにくくする
        //   ・ただしキュロットのような全周ではなく、内股側（脚と脚の間＝正面中央）を
        //     開けた部分円筒にする（＝「前にはプレートがない」構造）
        //   ・左右のhipにそれぞれ独立して付ける（腰ボーン＝hipに追従）
        if (data.topWear === 'armor') {
            const tassetPlateMat = new THREE.MeshLambertMaterial({
                color: data.plateColor || '#d8dce0', side: THREE.DoubleSide
            });
            const tassetTrimMat = new THREE.MeshLambertMaterial({
                color: data.plateTrimColor || '#d4af37', side: THREE.DoubleSide
            });

            const tTopR = thighTopR + 0.10;
            const tBotR = thighBotR + 0.34; // 裾を広げて脚の振り幅を吸収（キュロットと同じ考え方）
            const tLen  = thighLen * 0.60;  // 太もも半ばまで（膝には届かせない）

            // 内股側（他方の脚に近い側）を120°分開ける
            const innerTheta = (xPos > 0) ? Math.PI * 1.5 : Math.PI * 0.5;
            const gapHalf = Math.PI / 3; // 開口部の半角（合計120°）
            const tThetaStart  = innerTheta + gapHalf;
            const tThetaLength = Math.PI * 2 - gapHalf * 2; // 残り240°がプレート

            const tassetGeo = new THREE.CylinderGeometry(
                tTopR, tBotR, tLen, 20, 1, true, tThetaStart, tThetaLength
            );
            tassetGeo.translate(0, -tLen / 2, 0);
            const tasset = new THREE.Mesh(tassetGeo, tassetPlateMat);
            hip.add(tasset);

            // 腰まわり（上端）の金縁：同じ開口角の薄い帯で継ぎ目を隠す
            const tTopBandGeo = new THREE.CylinderGeometry(
                tTopR + 0.015, tTopR + 0.015, 0.06, 20, 1, true, tThetaStart, tThetaLength
            );
            const tTopBand = new THREE.Mesh(tTopBandGeo, tassetTrimMat);
            hip.add(tTopBand);

            // 裾（下端）の金縁：同じ開口角の帯
            const tHemGeo = new THREE.CylinderGeometry(
                tBotR + 0.02, tBotR + 0.02, 0.05, 20, 1, true, tThetaStart, tThetaLength
            );
            const tHem = new THREE.Mesh(tHemGeo, tassetTrimMat);
            tHem.position.y = -tLen;
            hip.add(tHem);
        }

        // ── 軽装プレートアーマー：脛当て（膝キャップ＋すね当て、左右） ──
        // 【設計方針】
        //   ・knee（膝関節）の子として追加。膝を曲げる・しゃがむポーズにも一緒に追従する
        //   ・実際の甲冑と同じく前面のみを覆い、背面（ふくらはぎ側）は開けておく
        //     → しゃがみ／膝立ちポーズで背面が突っ張って変形して見えるのを防ぐため
        if (data.topWear === 'armor') {
            const kneeArmorMat = new THREE.MeshLambertMaterial({
                color: data.plateColor || '#d8dce0', side: THREE.DoubleSide
            });
            const kneeArmorTrimMat = new THREE.MeshLambertMaterial({
                color: data.plateTrimColor || '#d4af37', side: THREE.DoubleSide
            });

            // 膝キャップ：膝関節を前から覆う丸いドーム
            // （上向きの半球を90°倒して前(+Z)向きのドームにする）
            const kneeCapR = kneeR + 0.09;
            const kneeCapGeo = new THREE.SphereGeometry(kneeCapR, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2);
            const kneeCap = new THREE.Mesh(kneeCapGeo, kneeArmorMat);
            kneeCap.rotation.x = Math.PI / 2;
            kneeCap.position.z = 0.06;
            knee.add(kneeCap);

            // 膝キャップ縁の金トリム（回転後のドーム境界は自然にXY平面の円になるため、
            // トーラスは追加回転なしでそのまま使える）
            const kneeRingGeo = new THREE.TorusGeometry(kneeCapR, 0.025, 8, 20);
            const kneeRing = new THREE.Mesh(kneeRingGeo, kneeArmorTrimMat);
            kneeRing.position.z = 0.06;
            knee.add(kneeRing);

            // すね当て：ふくらはぎの前面180°のみを覆う部分円筒（背面は開放）
            // ★ブーツ機能との干渉対策：
            //   既存の長靴シャフトは半径0.19・上端y=-0.30まで伸びている。
            //   すね当てをそこまで長くすると同じ場所で２つの筒が重なりチラつく(Zファイティング)ため、
            //   すね当てはブーツのシャフト上端でぴったり止め、下端半径もシャフトと同じ0.19にして
            //   継ぎ目が自然に見えるようにする（ブーツを履かない場合は少し脛が覗く形になる）
            const shinTopR = kneeR + 0.05;
            const shinBotR = 0.19; // 長靴シャフト半径(0.19)と揃える
            const shinTopY = -0.12;
            const shinBotY = -0.30; // 長靴シャフト上端(-0.30)と揃える
            const shinLen  = shinTopY - shinBotY;
            const shinThetaStart  = -Math.PI / 2;
            const shinThetaLength = Math.PI; // 前面180°のみ

            const shinGeo = new THREE.CylinderGeometry(
                shinTopR, shinBotR, shinLen, 16, 1, true, shinThetaStart, shinThetaLength
            );
            const shin = new THREE.Mesh(shinGeo, kneeArmorMat);
            shin.position.y = shinTopY - shinLen / 2;
            knee.add(shin);

            // すね当て上端（膝下）の金縁
            const shinTopBandGeo = new THREE.CylinderGeometry(
                shinTopR + 0.015, shinTopR + 0.015, 0.05, 16, 1, true, shinThetaStart, shinThetaLength
            );
            const shinTopBand = new THREE.Mesh(shinTopBandGeo, kneeArmorTrimMat);
            shinTopBand.position.y = shinTopY;
            knee.add(shinTopBand);

            // すね当て下端（足首上）の金縁
            const shinBotBandGeo = new THREE.CylinderGeometry(
                shinBotR + 0.015, shinBotR + 0.015, 0.05, 16, 1, true, shinThetaStart, shinThetaLength
            );
            const shinBotBand = new THREE.Mesh(shinBotBandGeo, kneeArmorTrimMat);
            shinBotBand.position.y = shinBotY;
            knee.add(shinBotBand);
        }

        // ── 足グループ（ankle直下・ポーズ追従） ──
        const foot = new THREE.Group();
        foot.position.set(0, -0.10, +0.18);
        ankle.add(foot);

        // ── 素足グループ ──
        const bareFootGroup = new THREE.Group();
        foot.add(bareFootGroup);

        // 【土台】扁平球体
        const soleSphere = new THREE.SphereGeometry(0.20, 20, 14);
        const sole = new THREE.Mesh(soleSphere, skinMat);
        sole.scale.set(0.95, 0.35, 1.6);
        sole.position.set(0, 0, +0.08);
        bareFootGroup.add(sole);

        // 【甲の盛り上がり】
        const instepGeo = new THREE.SphereGeometry(0.18, 16, 12);
        const instep = new THREE.Mesh(instepGeo, skinMat);
        instep.scale.set(0.80, 0.65, 1.55);
        instep.position.set(0, 0.08, +0.04);
        instep.rotation.x = 0.25;
        bareFootGroup.add(instep);

        // ── 長靴グループ（ankle親子でポーズ追従） ──
        const bootGroup = new THREE.Group();
        foot.add(bootGroup);

        // ankle基準でのオフセット（foot.position反映済み座標系）
        // foot原点=かかと付近、前方+Z、上方+Y
        const BOOT_Z = +0.10; // foot座標系でのZ中心

        const bootsColor = data.bootsColor && data.bootsColor !== 'none' ? data.bootsColor : null;

        if (bootsColor) {
            const bootsMat = new THREE.MeshLambertMaterial({ color: bootsColor });

            // ── ソール（足裏の厚底） ──
            const soleRx = 0.24, soleRz = 0.54, soleH = 0.20;
            const soleGeo = new THREE.CylinderGeometry(soleRx, soleRx, soleH, 24, 1, false);
            const sPos = soleGeo.attributes.position;
            for (let i = 0; i < sPos.count; i++) sPos.setZ(i, sPos.getZ(i) * (soleRz / soleRx));
            sPos.needsUpdate = true;
            soleGeo.computeVertexNormals();
            const bootSole = new THREE.Mesh(soleGeo, bootsMat);
            bootSole.position.set(0, -0.18, BOOT_Z);
            bootGroup.add(bootSole);

            // ソール底面
            const soleBotGeo = new THREE.CircleGeometry(soleRx, 24);
            const soleBotMesh = new THREE.Mesh(soleBotGeo, bootsMat);
            soleBotMesh.rotation.x = -Math.PI / 2;
            soleBotMesh.scale.set(1, soleRz / soleRx, 1);
            soleBotMesh.position.set(0, -0.28, BOOT_Z);
            bootGroup.add(soleBotMesh);

            // ── トゥ（足先を覆う楕円筒） ──
            const toeRx = 0.22, toeRz = 0.54, toeH = 0.28;
            const toeGeo = new THREE.CylinderGeometry(toeRx, toeRx, toeH, 20, 1, false);
            const tPos = toeGeo.attributes.position;
            for (let i = 0; i < tPos.count; i++) tPos.setZ(i, tPos.getZ(i) * (toeRz / toeRx));
            tPos.needsUpdate = true;
            toeGeo.computeVertexNormals();
            const toe = new THREE.Mesh(toeGeo, bootsMat);
            toe.position.set(0, -0.06, BOOT_Z);
            bootGroup.add(toe);

            // ── シャフト（足首〜すねの筒）──
            // foot座標系: ankleはfoot親の上なのでシャフトはanкleへ直接追加
            const shaftH = 0.55, shaftR = 0.19;
            const shaftGeo = new THREE.CylinderGeometry(shaftR, shaftR, shaftH, 20);
            const shaft = new THREE.Mesh(shaftGeo, bootsMat);
            // ankleの子として追加（foot座標系から抜けてankle直下に）
            shaft.position.set(0, -calfLen + shaftH / 2, 0);
            knee.add(shaft); // knee直下のankleと同じ親

            // 履き口
            const cuffGeo = new THREE.CylinderGeometry(shaftR + 0.015, shaftR, 0.04, 20);
            const cuff = new THREE.Mesh(cuffGeo, bootsMat);
            cuff.position.set(0, -calfLen + shaftH - 0.02, 0);
            knee.add(cuff);
        }

        // 表示切替
        bareFootGroup.visible = !(data.bootsColor && data.bootsColor !== 'none');
        bootGroup.visible     =  (data.bootsColor && data.bootsColor !== 'none');

        pelvisMesh.parent ? pelvisMesh.parent.add(hip) : characterGroup.add(hip);
        // ★ankleを追加公開：ロングスカートの裾延長(createLongSkirtExtension)が
        //   足首のワールド座標を参照するために必要。既存のroot/jointは変更なし。
        return { root: hip, joint: knee, ankle };
    }

    animatedParts.arms.push(createArm(0.65));  
    animatedParts.arms.push(createArm(-0.65)); 

    // ── 軽装プレートアーマー：肩当て ──
    // ★注意：shoulderメッシュはcreateArm()実行時点でようやく生成されるため、
    //   ここ（腕生成の直後）で呼ぶ必要がある。胸当てと同じ場所で呼ぶと
    //   まだ肩関節が存在せず、肩当てが1つも装着されないバグになる。
    if (data.topWear === 'armor') {
        createShoulderArmor(data, characterGroup);
    }

    const legPantsColor = (data.bottomWear === 'pants') ? data.pantsColor : null;
    const legCulotteColor = (data.bottomWear === 'culotte') ? data.skirtColor : null;
    animatedParts.legs.push(createLeg(0.378,  pelvis, legPantsColor, legCulotteColor)); 
    animatedParts.legs.push(createLeg(-0.378, pelvis, legPantsColor, legCulotteColor)); 

    // ── 下半身装備：スカート（腰・左右膝ボーンに追従する動的版） ──
    // 左右の膝ボーン(hip/knee)が上のcreateLeg()×2で生成済みになった
    // この時点でのみ呼び出せる（createLeg以前だと膝の参照が取れない）。
    // ★ロングスカートも「スカート本体」自体は全く同じものを使う
    //   （下の裾延長パーツを継ぎ足すことで長くする方式のため）。
    if ((data.bottomWear === 'skirt' || data.bottomWear === 'longskirt') && data.skirtColor && data.skirtColor !== 'none') {
        animatedParts.skirt = createDynamicSkirt(data.skirtColor, characterGroup, pelvis, animatedParts.legs);
    } else {
        animatedParts.skirt = null;
    }

    // ── 下半身装備：ロングスカートの裾延長パーツ ──
    // 「スカート」本体（上のcreateDynamicSkirt、内部構造は無改造）の裾に、
    // 足首基準の大きなカプセル型をつなげて足元まで伸ばす追加パーツ。
    // 詳細な設計はcreateLongSkirtExtension()のコメントを参照。
    if (data.bottomWear === 'longskirt' && data.skirtColor && data.skirtColor !== 'none') {
        animatedParts.longSkirtExt = createLongSkirtExtension(data.skirtColor, characterGroup, animatedParts.skirt, animatedParts.legs);
    } else {
        animatedParts.longSkirtExt = null;
    }

    // ── 小道具：右手に剣（または大剣）を持たせる ──
    // 後方互換：古い保存データはswordTypeが無くhasSword(true/false)しか持たない場合がある
    const swordType = data.swordType || (data.hasSword ? 'sword' : 'none');
    if (swordType !== 'none') {
        const swordScale = (swordType === 'greatsword') ? 2 : 1; // 大剣は通常の剣の2倍サイズ
        const sword = createSword(swordScale);
        // arms[1] = 右腕。wristの子にすることで腕の動き・ポーズに追従する
        animatedParts.arms[1].wrist.add(sword);
        // 握りやすいよう基本姿勢を設定（ポーズごとにswordTiltXで上下に調整される）
        sword.rotation.set(SWORD_BASE_ROTATION.x, SWORD_BASE_ROTATION.y, SWORD_BASE_ROTATION.z);
        animatedParts.sword = sword;
    } else {
        animatedParts.sword = null;
    }

    // ── 小道具：左手にシールドを持たせる ──
    if (data.hasShield) {
        const shield = createShield();
        // arms[0] = 左腕。wristの子にすることで腕の動き・ポーズに追従する
        animatedParts.arms[0].wrist.add(shield);
        shield.position.set(0.20, -0.02, 0.02);
        shield.rotation.set(0, Math.PI / 2, 0);
        animatedParts.shield = shield;
    } else {
        animatedParts.shield = null;
    }

    // 長靴はcreateLeg()内でankle親子として生成済み

    scene.add(characterGroup);
    if (window._poseEditApplyAll) window._poseEditApplyAll();
    // キャラ再構築で顔メッシュが新しいオブジェクトに置き換わったので、
    // 直前まで表示していた表情（ポーズ専用 or デフォルト）を再適用する
    if (window._reapplyCurrentExpression) window._reapplyCurrentExpression();
}
