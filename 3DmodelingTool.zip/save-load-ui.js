// ============================================================
// セーブ / ロード（JSON）
// ============================================================
function buildSaveData() {
    return {
        version: 1,
        characterData: characterData,
        poseSnapshot: captureFullPoseSnapshot(),
        mySlots: mySlots,
    };
}

document.getElementById('saveDataBtn').addEventListener('click', () => {
    const data = buildSaveData();
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = URL.createObjectURL(blob);
    a.download = '3dmaker_save.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
    showSlotStatus('💾 保存ファイルをダウンロードしました');
});

document.getElementById('loadDataBtn').addEventListener('click', () => {
    document.getElementById('loadFileInput').click();
});

document.getElementById('loadFileInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
        try {
            const data = JSON.parse(ev.target.result);
            if (!data.version || !data.characterData) throw new Error('不正なファイル');

            // キャラクターカスタマイズを復元
            const hadTopWear = data.characterData.topWear !== undefined;
            const hadSwordType = data.characterData.swordType !== undefined;
            Object.assign(characterData, data.characterData);
            if (!hadTopWear) {
                // 古い保存ファイル：shirtColorから衣装タイプを推定する
                characterData.topWear = (characterData.shirtColor && characterData.shirtColor !== 'none') ? 'shirt' : 'none';
            }
            if (!hadSwordType) {
                // 古い保存ファイル：hasSword(true/false)からswordTypeを推定する
                characterData.swordType = characterData.hasSword ? 'sword' : 'none';
            }
            createCharacter(characterData);
            restoreCustomizeUI(characterData);

            // ポーズを復元
            if (data.poseSnapshot) {
                setTimeout(() => applyPoseSnapshot(data.poseSnapshot), 100);
            }
            activeSlotIndex = -1; // 読込直後はどのプリセットにも自動保存しない

            // マイポーズスロットを復元
            // ※スロット数(SLOT_COUNT)が変わった過去のセーブファイルにも対応:
            //   名前で対応づけて復元するので、新しいポーズが途中に追加されていても
            //   既存の編集済みポーズが別スロットの位置にずれて壊れることがない
            if (Array.isArray(data.mySlots) && data.mySlots.length > 0) {
                mySlots = (data.mySlots.length === SLOT_COUNT)
                    ? data.mySlots
                    : reconcileSlots(data.mySlots);
                // ★表情システム改修：旧形式の保存ファイル（expressionフィールドが無い）にも
                //   対応するため、安全な初期値を補いつつディープコピーで独立させる
                mySlots = mySlots.map(normalizeSlotExpression);
                saveSlots(mySlots);
                buildSlotButtons();
            }
            if (window.syncAllExpressionEditors) window.syncAllExpressionEditors();

            showSlotStatus('📂 読み込み完了！');
        } catch(err) {
            showSlotStatus('⚠️ 読み込み失敗: ' + err.message);
        }
        e.target.value = '';
    };
    reader.readAsText(file);
});

// カスタマイズUIをデータから復元する
function restoreCustomizeUI(data) {
    // スライダー
    const sliderMap = {
        headScaleX: data.headScaleX,
        headScaleY: data.headScaleY,
        jawWidth:   data.jawWidth,
        bustSize:   data.bustSize,
        bustProtrude: data.bustProtrude,
    };
    Object.entries(sliderMap).forEach(([id, val]) => {
        const el = document.getElementById(id);
        if (el && val !== undefined) el.value = val;
    });

    // セレクト（★表情システム改修：eyeType/mouthType/eyebrowTypeは
    //   キャラ固有の項目ではなくなったため復元対象から除外）
    ['hairType','earType'].forEach(id => {
        const el = document.getElementById(id);
        if (el && data[id]) el.value = data[id];
    });

    // 肌色
    const bodyColorVal = data.bodyColor || '#ffe0c0';
    document.getElementById('bodyColor').value = bodyColorVal;
    const skinPresetSet = ['#ffe0c0', '#d9a066', '#fff1e6'];
    document.getElementById('skinColorSelect').value = skinPresetSet.includes(bodyColorVal.toLowerCase()) ? bodyColorVal.toLowerCase() : 'custom';

    // 目の色
    const eyeColorVal = data.eyeColor || '#000000';
    document.getElementById('eyeColor').value = eyeColorVal;
    const eyePresetSet = ['#000000', '#7a4a2b', '#3f7fd9', '#3f9d6b', '#8a5cc4', '#c23b3b', '#d1a44e', '#e07fb0'];
    document.getElementById('eyeColorSelect').value = eyePresetSet.includes(eyeColorVal.toLowerCase()) ? eyeColorVal.toLowerCase() : 'custom';

    // 髪色
    const hairColorVal = data.hairColor || '#333333';
    document.getElementById('hairColor').value = hairColorVal;
    const hairPresetSet = ['#333333', '#6b4226', '#e6c477', '#d8d8e0', '#a33a2c', '#f2a6c6', '#3f6fb0', '#7a5ca8'];
    document.getElementById('hairColorSelect').value = hairPresetSet.includes(hairColorVal.toLowerCase()) ? hairColorVal.toLowerCase() : 'custom';

    // 衣装（上半身）：なし / Tシャツ / 軽装プレートアーマー
    const topWear = data.topWear || ((data.shirtColor && data.shirtColor !== 'none') ? 'shirt' : 'none');
    document.getElementById('topWearSelect').value = topWear;
    document.getElementById('shirtColorGroup').style.display = (topWear === 'shirt') ? '' : 'none';
    if (data.shirtColor && data.shirtColor !== 'none') document.getElementById('shirtColor').value = data.shirtColor;
    const showPlate = (topWear === 'armor') || !!data.hasHelmet;
    document.getElementById('plateColorGroup').style.display = showPlate ? '' : 'none';
    document.getElementById('plateTrimColorGroup').style.display = showPlate ? '' : 'none';
    if (data.plateColor) document.getElementById('plateColor').value = data.plateColor;
    if (data.plateTrimColor) document.getElementById('plateTrimColor').value = data.plateTrimColor;

    // 下半身装備（なし / ズボン / スカート / キュロット / ロングスカート）
    const bottomWear = data.bottomWear || 'none';
    document.getElementById('bottomWearSelect').value = bottomWear;
    document.getElementById('pantsColorGroup').style.display = (bottomWear === 'pants') ? '' : 'none';
    document.getElementById('skirtColorGroup').style.display = (bottomWear === 'skirt' || bottomWear === 'culotte' || bottomWear === 'longskirt') ? '' : 'none';
    if (data.pantsColor && data.pantsColor !== 'none') document.getElementById('pantsColor').value = data.pantsColor;
    if (data.skirtColor && data.skirtColor !== 'none') document.getElementById('skirtColor').value = data.skirtColor;

    // 履き物（長靴）
    const wearBoots = data.bootsColor && data.bootsColor !== 'none';
    document.getElementById('bootsSelect').value = wearBoots ? 'true' : 'false';
    document.getElementById('bootsColorGroup').style.display = wearBoots ? '' : 'none';
    if (wearBoots) document.getElementById('bootsColor').value = data.bootsColor;

    // 右手（剣）（後方互換：旧hasSwordしか無い保存データはsword扱いにする）
    const swordTypeUI = data.swordType || (data.hasSword ? 'sword' : 'none');
    document.getElementById('swordSelect').value = swordTypeUI;

    // 左手（盾）
    document.getElementById('shieldSelect').value = data.hasShield ? 'true' : 'false';

    // 頭（ヘルメット／軽装プレートアーマー）
    document.getElementById('helmetSelect').value = data.hasHelmet ? 'true' : 'false';
}

// ============================================================
// ポーズボタンを動的生成
// ============================================================
// buildPoseButtons は buildSlotButtons に統合されました。
// コマンドボタンだけここで生成する。
function buildCommandButtons() {
    const cmdContainer = document.getElementById('command-buttons');
    if (!cmdContainer) return;

    COMMANDS.forEach((cmd) => {
        const btn = document.createElement('button');
        btn.className = 'cmd-btn';
        btn.textContent = cmd.label;
        btn.addEventListener('click', () => playCommand(cmd));
        cmdContainer.appendChild(btn);
        commandButtonEls.set(cmd, btn);
    });
}
buildCommandButtons();
buildSlotButtons();

const clock = new THREE.Clock();
function animate() {
    requestAnimationFrame(animate);
    const time = clock.getElapsedTime();
    
    const dt = clock.getDelta ? 0.016 : 0.016; // getDeltaは上で使用済みのため固定値

    // 頭のふわふわ（headPivotの子headのY位置を微動）
    if (animatedParts.head) {
        const headMesh = animatedParts.head.children[0]; // headPivotの子 = headメッシュ
        if (headMesh) {
            headMesh.position.y = Math.sin(time * 2) * 0.03; // headPivot相対でY微動
        }
    }

    // ポニーテールの揺れ（常時・ポーズや首の動きに関わらず自然に追従）
    if (animatedParts.ponyTail) {
        animatedParts.ponyTail.rotation.x = Math.sin(time * 3) * 0.05;
        animatedParts.ponyTail.rotation.z = Math.sin(time * 2) * 0.03;
    }

    if (idleEnabled) {
        // ── アイドルアニメ（完全優先） ──
        if (animatedParts.chest && animatedParts.belly) {
            animatedParts.chest.rotation.x = Math.sin(time * 2) * 0.05;
            animatedParts.belly.rotation.x = Math.sin(time * 2) * 0.02;
        }
        animatedParts.arms.forEach((arm, index) => {
            const sign = index === 0 ? 1 : -1;
            arm.root.rotation.x = Math.sin(time * 1.5) * 0.2 * sign;
            arm.root.rotation.y = 0;
            arm.root.rotation.z = 0.1 * sign;
            arm.joint.rotation.x = -0.1 + Math.sin(time * 1.5 + 1.0) * 0.1;
            arm.joint.rotation.z = 0;
        });
        animatedParts.legs.forEach((leg) => {
            leg.root.rotation.x = -0.05 + Math.sin(time * 2) * 0.02;
            leg.root.rotation.z = 0;
            leg.joint.rotation.x = 0.1 - Math.sin(time * 2) * 0.04;
        });
    } else {
        // ── シーケンス進行 & ポーズ補間 ──
        tickSequence(0.016);
        tickPoseLerp(0.016);
    }
    controls.update();
    if (window._poseEditGizmoUpdate) window._poseEditGizmoUpdate();
    // スカート追従はこのフレームの脚の回転が確定した最後（render直前）に行う
    if (animatedParts.skirt) updateDynamicSkirt(animatedParts.skirt);
    if (animatedParts.longSkirtExt) updateLongSkirtExtension(animatedParts.longSkirtExt);
    renderer.render(scene, camera);
}
animate();
